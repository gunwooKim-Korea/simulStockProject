package stock.fw;
//SQL�� �����ϴ� Ŭ���� - �����ӿ�ũ ������� ������Ʈ�� �ϴ� ��� XML���·� ����
public class stockQuery {
   
   
   public static String STOCK_LIST
    ="select * from(select rownum count,stock.* from stock,company where stock.stock_code = company.stock_cd and company.crp_cls='Y') where count between ? and ?";
   
   public static String STOCK_LIST2
   ="select * from(select rownum count,stock.* from stock,company where stock.stock_code = company.stock_cd and company.crp_cls='K') where count between ? and ?";
  
   public static String STOCK_SEARCH
    ="select * from (select rownum count,stock.* from stock,company where stock.stock_code = company.stock_cd and company.crp_cls like '%Y%'  and STOCK_CODE like ? or STOCK_NAME like ? )where count between ? and ?";
   
   public static String STOCK_SEARCH2
   ="select * from (select rownum count,stock.* from stock,company where stock.stock_code = company.stock_cd and company.crp_cls like '%K%'  and STOCK_CODE like ? or STOCK_NAME like ? )where count between ? and ?";
 
   public static String SEARCH_COMPANY_NAME
  ="select CRP_NM from company where STOCK_CD=?" ;
   
   public static String BUY_INSERT
   ="insert into BuyStock values(?,?,sysdate,?,?)";
   
   public static String SELL_INSERT
   ="insert into SellStock values(?,?,sysdate,?,?)";
   
   public static String COMPANY_INFO
    ="select * from company where crp_nm like ?";
   
   public static String HAVE_INSERT
   ="insert into HaveStock values(?,?,?)";
   
   public static String SEARCH_HAVE_COUNT
    ="select COUNT from HaveStock where mem_id =? and company_id = ?";
   
   public static String SEARCH_STOCK
    ="select * from stock where stock_code =?";
   
   public static String HAVE_UPDATE
   ="update HaveStock set count= ? where company_id = ?";
   
   public static String SEARCH_HAVESTOCK
    ="select * from HaveStock where mem_id =?";
   
   public static String SEARCH_REALSTOCK
   = "select * from realstock where stock_cd = ? and rownum <= 20 order by time desc";
   
   public static String STOCK_LIKELIST
    ="select * from (select rownum count,stock.* from stock) st, liketab lt where count between ? and ? "
          + "and lt.mem_id = ? and st.stock_code = lt.stock_cd";

   public static String STOCK_SEARCHLIKELIST
    ="select * from (select rownum count,stock.* from stock where STOCK_CODE like ? or STOCK_NAME like ?) st, liketab lt "
          + " where count between ? and ? "
          + " and mem_id = ? and st.stock_code = lt.stock_cd";
    public static String DELETE_HAVE_STOCK
       ="delete  from HaveStock where mem_id =? and company_id = ?";
    
    public static String SEARCH_POINT_CHECK
    ="select point from capital where mem_id= ? ";
    
    public static String SEARCH_POINT_CHECK2
    ="select point from member where mem_id=?";
    
    public static String SEARCH_COMPANYSTOCK
    = "select * from sevenday where stock_cd = ? and rownum <= 20 order by day desc";

}






