package stock.dto;

public class sellDTO {

	String mem_id ;
	
	String company_id ;
	int sell_price ;
	int sell_count ;

	public int getSell_price() {
		return sell_price;
	}
	public void setSell_price(int sell_price) {
		this.sell_price = sell_price;
	}
	public int getSell_count() {
		return sell_count;
	}
	public void setSell_count(int sell_count) {
		this.sell_count = sell_count;
	}

	
	public String toString() {
		return "sellDTO [ mem_id=" + mem_id
				+ ", company_id=" + company_id +
				 ", sell_price=" + sell_price + ", sell_count=" + sell_count
				+ "]";
	}
	public sellDTO( String mem_id, String company_id,
			int sell_price, int sell_count) {
		super();
		
		this.mem_id = mem_id;
		this.company_id = company_id;
	
		this.sell_price = sell_price;
		this.sell_count = sell_count;
	}


	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getCompany_id() {
		return company_id;
	}
	public void setCompany_id(String company_id) {
		this.company_id = company_id;
	}


	}


