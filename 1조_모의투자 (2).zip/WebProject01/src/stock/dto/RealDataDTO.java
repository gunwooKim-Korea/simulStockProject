package stock.dto;

public class RealDataDTO {
	String stock_id;
	String now;
	String price;
	public RealDataDTO(String stock_id, String now, String price) {
		super();
		this.stock_id = stock_id;
		this.now = now;
		this.price = price;
	}
	public String getStock_id() {
		return stock_id;
	}
	public void setStock_id(String stock_id) {
		this.stock_id = stock_id;
	}
	public String getNow() {
		return now;
	}
	public void setNow(String now) {
		this.now = now;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "RealDataDTO [stock_id=" + stock_id + ", now=" + now
				+ ", price=" + price + "]";
	}
	
	
}
