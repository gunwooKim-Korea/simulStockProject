package stock.dao;

import static company.fw.companyQuery.*;
import static fw.MemberQuery.*;
import static stock.fw.stockQuery.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import member.dto.MemberDTO;
import stock.dto.RealDataDTO;
import stock.dto.buyDTO;
import stock.dto.companyInfoDTO;
import stock.dto.haveDTO;
import stock.dto.sellDTO;
import stock.dto.stockDTO;
import fw.DBUtil;

public class stockDAOImpl implements stockDAO {

	
	public int pointCheck2(String mem_id) {
		int result = 0;

		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;

		try {
			con = DBUtil.getConnection();

			ptmt = con.prepareStatement(SEARCH_POINT_CHECK2);

			ptmt.setString(1, mem_id);
		

			rs = ptmt.executeQuery();

			while (rs.next()) {

				result = rs.getInt(1);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(null, ptmt, con);
		}

		return result;
	}
	
	
	public int pointCheck(String mem_id) {
		int result = 0;

		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;

		try {
			con = DBUtil.getConnection();

			ptmt = con.prepareStatement(SEARCH_POINT_CHECK);

			ptmt.setString(1, mem_id);
		

			rs = ptmt.executeQuery();

			while (rs.next()) {

				result = rs.getInt(1);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(null, ptmt, con);
		}

		return result;
	}
	
	
	public int delete_have_count(String company_id, String mem_id) {
		int result=0;
		
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;

		try {
			con = DBUtil.getConnection();

			ptmt = con.prepareStatement(DELETE_HAVE_STOCK);
			
			ptmt.setString(1, mem_id);
			ptmt.setString(2, company_id);

			result = ptmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(null, ptmt, con);
		}

		return result;
	}


	@Override
	
	public ArrayList<stockDTO> getStockList(String search,int page) {
		ArrayList<stockDTO> list = new ArrayList<stockDTO>();
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;
		stockDTO stock = null;
		int a = ((page-1)*15)+1;
		int b = (page*15);

		try {
			con = DBUtil.getConnection();

			if (search == null || search.equals("null") || search == "") {
				ptmt = con.prepareStatement(STOCK_LIST);
				ptmt.setInt(1, a);
				ptmt.setInt(2, b);
			} else {
				ptmt = con.prepareStatement(STOCK_SEARCH);
				ptmt.setString(1, "%" + search + "%");
				ptmt.setString(2, "%" + search + "%");
				ptmt.setInt(3, a);
				ptmt.setInt(4, b);

			}
			
			rs = ptmt.executeQuery();
			while (rs.next()) {
				stock = new stockDTO( rs.getString(2),
						rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getString(8),
						rs.getString(9),rs.getString(10));

				list.add(stock);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			DBUtil.close(rs, ptmt, con);
		}

		return list;
	}
	public ArrayList<stockDTO> getStockList2(String search,int page) {
		ArrayList<stockDTO> list = new ArrayList<stockDTO>();
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;
		stockDTO stock = null;
		int a = ((page-1)*15)+1;
		int b = (page*15);

		try {
			con = DBUtil.getConnection();

			if (search == null || search.equals("null") || search == "") {
				ptmt = con.prepareStatement(STOCK_LIST2);
				ptmt.setInt(1, a);
				ptmt.setInt(2, b);
			} else {
				ptmt = con.prepareStatement(STOCK_SEARCH2);
				ptmt.setString(1, "%" + search + "%");
				ptmt.setString(2, "%" + search + "%");
				ptmt.setInt(3, a);
				ptmt.setInt(4, b);

			}
			
			rs = ptmt.executeQuery();
			while (rs.next()) {
				stock = new stockDTO( rs.getString(2),
						rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getString(8),
						rs.getString(9),rs.getString(10));

				list.add(stock);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			DBUtil.close(rs, ptmt, con);
		}

		return list;
	}

	@Override
	public int buyStock(buyDTO buy) {
		Connection con = null;
		PreparedStatement ptmt = null;
		int result = 0;
		try {
			con = DBUtil.getConnection();
			ptmt = con.prepareStatement(BUY_INSERT);
			ptmt.setString(1, buy.getMem_id());
			ptmt.setString(2, buy.getCompany_id());

			ptmt.setInt(3, buy.getBuy_price());
			ptmt.setInt(4, buy.getBuy_count());

			result = ptmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(null, ptmt, con);
		}
		return result;
	}

	@Override
	public companyInfoDTO companyInfo(String Stock_name) {

		companyInfoDTO info = null;
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;

		try {
			con = DBUtil.getConnection();

			ptmt = con.prepareStatement(COMPANY_INFO);

			ptmt.setString(1, "%" + Stock_name + "%");

			rs = ptmt.executeQuery();

			while (rs.next()) {

				info = new companyInfoDTO(rs.getString(1), rs.getString(2),
						rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getString(8),
						rs.getString(9), rs.getString(10), rs.getString(11),
						rs.getString(12), rs.getString(13), rs.getString(14),
						rs.getString(15), rs.getString(16));

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(null, ptmt, con);
		}

		return info;
	}

	public int haveStock(haveDTO have) {

		Connection con = null;
		PreparedStatement ptmt = null;
		int result = 0;
		try {
			con = DBUtil.getConnection();
			ptmt = con.prepareStatement(HAVE_INSERT);
			ptmt.setString(1, have.getMem_id());
			ptmt.setString(2, have.getCompany_id());
			ptmt.setInt(3, have.getCount());

			result = ptmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(null, ptmt, con);
		}
		return result;

	}

	@Override
	public int search_have_count(String company_id, String mem_id) {
		int result = 0;

		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;

		try {
			con = DBUtil.getConnection();

			ptmt = con.prepareStatement(SEARCH_HAVE_COUNT);

			ptmt.setString(1, mem_id);
			ptmt.setString(2, company_id);

			rs = ptmt.executeQuery();

			while (rs.next()) {

				result = rs.getInt(1);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(null, ptmt, con);
		}

		return result;
	}

	@Override
	public int sellStock(sellDTO selldto) {
		Connection con = null;
		PreparedStatement ptmt = null;
		int result = 0;
		try {
			con = DBUtil.getConnection();
			ptmt = con.prepareStatement(SELL_INSERT);
			ptmt.setString(1, selldto.getMem_id());
			ptmt.setString(2, selldto.getCompany_id());

			ptmt.setInt(3, selldto.getSell_price());
			ptmt.setInt(4, selldto.getSell_count());

			result = ptmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(null, ptmt, con);
		}
		return result;
	}


	@Override
	public stockDTO searchDTO(String stock_code) {

		stockDTO dto = null;
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;

		try {
			con = DBUtil.getConnection();

			ptmt = con.prepareStatement(SEARCH_STOCK);

			ptmt.setString(1, stock_code);
			rs = ptmt.executeQuery();

			while (rs.next()) {

				dto = new stockDTO(rs.getString(1), rs.getString(2),
						rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getString(8),
						rs.getString(9));

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(null, ptmt, con);
		}

		return dto;

	}

	@Override
	public ArrayList<haveDTO> haveAll() {

		ArrayList<haveDTO> list = new ArrayList<haveDTO>();
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;
		haveDTO have = null;

		try {
			con = DBUtil.getConnection();

			ptmt = con.prepareStatement(STOCK_LIST);
			rs = ptmt.executeQuery();
			while (rs.next()) {
				have = new haveDTO(rs.getString(1), rs.getString(2),
						rs.getInt(3));

				list.add(have);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			DBUtil.close(rs, ptmt, con);
		}

		return list;

	}

	@Override
	public int update(haveDTO havedto) {
		Connection con = null;
		PreparedStatement ptmt = null;
		int result = 0;
		try {
			con = DBUtil.getConnection();
			ptmt = con.prepareStatement(HAVE_UPDATE);

			ptmt.setInt(1, havedto.getCount());
			ptmt.setString(2, havedto.getCompany_id());

			result = ptmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(null, ptmt, con);
		}
		return result;

	}

	@Override
	public int update(String mem_id, int sum) {
		Connection con = null;
		PreparedStatement ptmt = null;
		int result = 0;
		try {

			con = DBUtil.getConnection();
			ptmt = con.prepareStatement(MEMBER_POINTUPDATE);

			ptmt.setString(2, mem_id);
			ptmt.setInt(1, sum);

			result = ptmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(null, ptmt, con);
		}
		return result;
	}

	public ArrayList<haveDTO> search_havestock(String mem_id) {
		int result = 0;

		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;
		ArrayList<haveDTO> havelist = new ArrayList<haveDTO>();
		haveDTO havedto = null;

		try {
			con = DBUtil.getConnection();

			ptmt = con.prepareStatement(SEARCH_HAVESTOCK);

			ptmt.setString(1, mem_id);

			rs = ptmt.executeQuery();

			while (rs.next()) {
				// System.out.println("**********************"+rs.getString(2));
				// System.out.println("**********************"+rs.getInt(3));
				havedto = new haveDTO(rs.getString(1), rs.getString(2),
						rs.getInt(3));
				havelist.add(havedto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(null, ptmt, con);
		}

		return havelist;
	}

	public int getTotal(String search) {
		int total = 0;
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;
		try {
			con = DBUtil.getConnection();

			if (search == null || search.equals("null") || search == "") {
				ptmt = con.prepareStatement(COMPANY_TOTAL);
			} else {
				ptmt = con.prepareStatement(COMPANY_SEARCHTOTAL);
				ptmt.setString(1, "%" + search + "%");
				ptmt.setString(2, "%" + search + "%");
			}
			rs = ptmt.executeQuery();
			if (rs.next()) {
				total = rs.getInt(1);
			}
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			DBUtil.close(rs, ptmt, con);
		}

		return total;
	}

	@Override
	public ArrayList<RealDataDTO> getRealStock(String stock_id) {
		int result = 0;

		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;
		ArrayList<RealDataDTO> arry = new ArrayList<RealDataDTO>();
		RealDataDTO realdto = null;

		try {
			con = DBUtil.getConnection();
			ptmt = con.prepareStatement(SEARCH_REALSTOCK);

			ptmt.setString(1, stock_id);

			rs = ptmt.executeQuery();

			while (rs.next()) {
				realdto = new RealDataDTO(rs.getString(1), rs.getString(2),
						rs.getString(3));
				arry.add(realdto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(null, ptmt, con);
		}

		return arry;
	}

	@Override
	public ArrayList<stockDTO> getStockLikeList(String search, int page,
			MemberDTO user) {
		ArrayList<stockDTO> list = new ArrayList<stockDTO>();
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;
		stockDTO stock = null;
		int a = ((page-1)*15)+1;
		int b = (page*15);

		try {
			con = DBUtil.getConnection();
			
			if (search == null || search.equals("null") || search == "") {
				ptmt = con.prepareStatement(STOCK_LIKELIST);
				ptmt.setInt(1, a);
				ptmt.setInt(2, b);
				ptmt.setString(3, user.getMem_id());
			} else {
				ptmt = con.prepareStatement(STOCK_SEARCHLIKELIST);
				ptmt.setString(1, "%" + search + "%");
				ptmt.setString(2, "%" + search + "%");
				ptmt.setInt(3, a);
				ptmt.setInt(4, b);
				ptmt.setString(5, user.getMem_id());
			}
			rs = ptmt.executeQuery();
			
			
			while (rs.next()) {
				
				stock = new stockDTO( rs.getString(2),
						rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getString(8),
						rs.getString(9),rs.getString(10));
				list.add(stock);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			DBUtil.close(rs, ptmt, con);
		}
		return list;
	}
	
	@Override
	public ArrayList<RealDataDTO> getCompanyStock(String stock_id) {
		int result = 0;

		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;
		ArrayList<RealDataDTO> arry = new ArrayList<RealDataDTO>();
		RealDataDTO realdto = null;

		try {
			con = DBUtil.getConnection();
			ptmt = con.prepareStatement(SEARCH_COMPANYSTOCK);

			ptmt.setString(1, stock_id);

			rs = ptmt.executeQuery();

			while (rs.next()) {
				realdto = new RealDataDTO(rs.getString(1), rs.getString(2),
						rs.getString(3));
				//System.out.println(realdto.toString());
				arry.add(realdto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(null, ptmt, con);
		}

		return arry;
	}


	@Override
	public String getCompanyName(String Stock_code) {
		String name = "";
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;

		try {
			con = DBUtil.getConnection();

			ptmt = con.prepareStatement(SEARCH_COMPANY_NAME);
			ptmt.setString(1, Stock_code);
			rs = ptmt.executeQuery();

			if (rs.next()) {

				name = rs.getString(1);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(null, ptmt, con);
		}

		return name;
	}

}
