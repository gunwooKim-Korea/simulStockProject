package stock.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import member.dto.MemberDTO;
import member.dto.MemhaveDTO;
import member.service.MemberService;
import member.service.MemberServiceImpl;
import stock.dto.buyDTO;
import stock.dto.haveDTO;
import stock.dto.sellDTO;
import stock.dto.stockDTO;
import stock.service.stockService;
import stock.service.stockServiceImpl;

@WebServlet(name = "sell", urlPatterns = { "/sell.do" })
public class sell extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse resp)
			throws ServletException, IOException {

		String price2 = (String) request.getParameter("price");
		String id = (String) request.getParameter("mem_id");
		String Stock_code = (String) request.getParameter("company_id");
		String val = (String) request.getParameter("val");

		int price = Integer.parseInt(price2);
		stockService service = new stockServiceImpl();
		int have = service.search_have_count(Stock_code, id);

		MemberService service2 = new MemberServiceImpl();
		MemberDTO mem = service2.search(id);
		System.out.println(mem.toString());
		int point = mem.getPoint();

		stockDTO stock = service.searchDTO(Stock_code);
		String msg = "";
		if (have > Integer.parseInt(val)) {

			int sum = point + price * Integer.parseInt(val);
			int val2 = have - Integer.parseInt(val);
			
			sellDTO selldto = new sellDTO(id, Stock_code, price,
					Integer.parseInt(val));
			int result = service.sellStock(selldto);
			haveDTO havedto2 = new haveDTO(id, Stock_code, val2);
			int result2 = service.update(havedto2);
			int result3 = service2.pointupdate(id, sum);
			msg = "�Ǹż���1";
			ArrayList<haveDTO> havelist = service.search_havestock(id);
			request.setAttribute("havelist", havelist);

		} else if (have == Integer.parseInt(val)) {

			int result2 = service.delete_have_count(Stock_code, id);
			sellDTO selldto = new sellDTO(id, Stock_code, price,
					Integer.parseInt(val));
			int sum = point + price * Integer.parseInt(val);
			int result3 = service2.pointupdate(id, sum);
			
			int result = service.sellStock(selldto);
			msg = "�Ǹż���2";

		} else {

			msg = "�ǸŽ���";
		}
		
		
		

		MemberService service3 = new MemberServiceImpl();
		ArrayList<MemhaveDTO> list = service3.haveStock(id);


		request.setAttribute("havelist", list);
		request.setAttribute("Stock_code", Stock_code);
		request.setAttribute("id", id);
		request.setAttribute("msg", msg);
		request.setAttribute("menupath", "../myPage/myPage_menu.jsp");
		request.setAttribute("viewpath", "../myPage/myPage_stockHistory.jsp");

		RequestDispatcher rd = request
				.getRequestDispatcher("/layout/mainLayout.jsp");
		rd.forward(request, resp);
		
		
	
	

	}

}
