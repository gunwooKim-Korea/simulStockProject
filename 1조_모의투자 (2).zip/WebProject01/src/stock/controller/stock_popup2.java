package stock.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import member.dto.MemberDTO;
import member.service.MemberService;
import member.service.MemberServiceImpl;
import stock.dto.buyDTO;
import stock.dto.haveDTO;
import stock.dto.sellDTO;
import stock.dto.stockDTO;
import stock.service.stockService;
import stock.service.stockServiceImpl;

@WebServlet(name = "stock_popup2", urlPatterns = { "/stock_popup2.do" })
public class stock_popup2 extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse resp)
			throws ServletException, IOException {

	

		String price2 = (String) request.getParameter("price");
		String id = (String) request.getParameter("id");
		String Stock_code = (String) request.getParameter("Stock_code");
		String val = (String) request.getParameter("val");
	
		
	
	
		int price = Integer.parseInt(price2);

	
		
		stockService service = new stockServiceImpl();

		int have = service.search_have_count(Stock_code, id);

	

		
		haveDTO havedto = new haveDTO(id, Stock_code, 1);
		

		MemberService service2 = new MemberServiceImpl();
		MemberDTO mem = service2.search(id);
		//System.out.println(mem.toString());
		int point = mem.getPoint();
		//System.out.println(point);
		stockDTO stock = service.searchDTO(Stock_code);
	
		//System.out.println(price+","+point);
		
		
		/*
		if (have >= val) {
			int val2 = have-val;
			haveDTO havedto = new haveDTO("������̵�", "�����ڵ�", val2);
			int result = service.sellStock(selldto);
			int result2 = service.update(havedto);
			msg = "�Ǹż���";

		} else {

			msg = "�ֽļ����� �����մϴ�.";

		}*/
		
	/*	if (have >= val) {
			
				
				int sum = point + price*Integer.parseInt(val);
				
				int val2 = have - Integer.parseInt(val);
				
				sellDTO buydto = new sellDTO(id, Stock_code, price2, Integer.parseInt(val));
				
				int result = service.sellStock(selldto);
				
				haveDTO havedto2 = new haveDTO(id, Stock_code, val2);
				
				int result2 = service.update(havedto2);
				
							
				service2.update(id, sum);
				
				System.out.println("���ڼ���1");
			
			

		} else {
			System.out.println("�ǸŽ���");
		
		}
	
	*/
		 PrintWriter out = resp.getWriter();
		  String str="";
		   str = "<script language='javascript'>";
		   str += "opener.window.location.reload();"; 
		   str += "self.close();";  
		    str += "</script>";
		   out.print(str);
	

	}

}
