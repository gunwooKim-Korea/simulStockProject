package stock.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import stock.dto.buyDTO;
import stock.dto.companyInfoDTO;
import stock.dto.haveDTO;
import stock.dto.sellDTO;
import stock.dto.stockDTO;
import stock.service.stockService;
import stock.service.stockServiceImpl;

@WebServlet(name = "havestock", urlPatterns = { "/havestock.do" })
public class mypageServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		req.setCharacterEncoding("euc-kr");

		String Stock_code = req.getParameter("Stock_code");
		HttpSession sess = req.getSession();
		String id =(String)sess.getAttribute("id");
       /* System.out.println(id);
        System.out.println(id);
        System.out.println(id);
        System.out.println(id);*/
		
		//String mem_id = req.getParameter("mem_id");
	

		//companyInfoDTO info = new companyInfoDTO();
		stockService service = new stockServiceImpl();

		//stockDTO dto = service.searchDTO(Stock_code);
		ArrayList<haveDTO> havelist = service.haveAll();
		//System.out.println(havelist+"1123121231232");
		
		//info = service.companyInfo(dto.getStock_name());
		
		/*System.out.println(id);	
		System.out.println(Stock_code);
		System.out.println(dto.getCur_price());
		*/

		/*
		 * haveDTO have = new haveDTO(mem_id, stock_code, 1);
		 * 
		 * int result = service.buyStock(buy); int result2 =
		 * service.haveStock(have);
		 */
		//req.setAttribute("dto", dto);
		req.setAttribute("havelist", havelist);
		//req.setAttribute("info", info);
		req.setAttribute("Stock_code", Stock_code);
		req.setAttribute("id", id);
		//req.setAttribute("price", dto.getCur_price());
		
		
		
		req.setAttribute("menupath", "../myPage/myPage_menu.jsp");
		req.setAttribute("viewpath", "../myPage/myPage_stockHistory.jsp");

		RequestDispatcher rd = req
				.getRequestDispatcher("/layout/mainLayout.jsp");
		rd.forward(req, resp);

	}

}