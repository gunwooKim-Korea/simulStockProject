package developer.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import developer.dto.developerDTO;
import fw.DBUtil;

public class devDAOImpl implements devDAO {

	@Override
	public developerDTO getdev(String name) {
		String sql="select * from developer where name=?";
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;
		developerDTO dev = null;
	//	System.out.println(name +"�̸�!!!");
		try {
			con = DBUtil.getConnection();
			ptmt = con.prepareStatement(sql);
			ptmt.setString(1, name);
			 //System.out.println(ptmt);
			rs = ptmt.executeQuery();
			//
			if (rs.next()) {
				dev = new developerDTO(rs.getString(1), rs.getString(2),
						rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6),rs.getString(7));
				///System.out.println("����!!");
			}
			// System.out.println(dev.toString());
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			DBUtil.close(rs, ptmt, con);
		}

		return dev;
	}

}
