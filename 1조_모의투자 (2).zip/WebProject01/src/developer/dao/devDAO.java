package developer.dao;

import developer.dto.developerDTO;

public interface devDAO {

	developerDTO getdev(String name);

}
