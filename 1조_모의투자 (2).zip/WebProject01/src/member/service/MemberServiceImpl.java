package member.service;

import java.util.ArrayList;





import member.dao.MemberDAO;
import member.dao.MemberDAOImpl;
import member.dto.GainDTO;
import member.dto.MemberDTO;
import member.dto.MemhaveDTO;
import member.dto.TradeTop5DTO;
import member.dto.userHistoryDTO;

public class MemberServiceImpl implements MemberService {

	@Override
	public int insert(MemberDTO mem) {
		MemberDAOImpl dao = new MemberDAOImpl();
		int result = dao.insert(mem);
		return result;
	}

	@Override
	public MemberDTO login(String id, String pw) {
		MemberDAO dao = new MemberDAOImpl();
		MemberDTO dto = dao.login(id, pw);
		return dto;
	}
	
	public ArrayList<TradeTop5DTO> tradetop(){
		MemberDAO dao = new MemberDAOImpl();
		ArrayList<TradeTop5DTO> list = dao.tradetop();
		return list;
	}

	
	public ArrayList<userHistoryDTO> checkUserHistory(String id){
		MemberDAO dao = new MemberDAOImpl();
		ArrayList<userHistoryDTO> list = dao.checkUserHistory(id);
		return list;
		
	}
	public ArrayList<GainDTO> GainSearch(String id){
		MemberDAO dao = new MemberDAOImpl();
		ArrayList<GainDTO> list = dao.GainSearch(id);
		return list;
		
	}

	@Override
	public int update(MemberDTO mem) {
		MemberDAOImpl dao = new MemberDAOImpl();
		int result = dao.update(mem);
		return result;
	}

	@Override
	public MemberDTO search(String id) {
		MemberDAO dao = new MemberDAOImpl();
		MemberDTO dto = dao.search(id);
		return dto;
		}
	

	@Override
	public int pointupdate(String id, int point) {
		int result = 0;
		MemberDAO dao = new MemberDAOImpl();
		result = dao.pointupdate(id ,point);
		return result;
	}

	@Override
	public ArrayList<MemberDTO> getmemberList(String search, int page) {
		MemberDAO dao = new MemberDAOImpl();
		ArrayList<MemberDTO> memlist = dao.getmemberList(search,page);
		return memlist;
	}

	@Override
	public int getTotal(String search) {
		MemberDAO dao = new MemberDAOImpl();
		return dao.getTotal(search);
	}

	@Override
	public boolean idCheck(String mem_id) {
		MemberDAO dao = new MemberDAOImpl();		
		boolean state = dao.idCheck(mem_id);
		return state;
	}

	@Override
	public int insert2(MemberDTO mem) {
		MemberDAOImpl dao = new MemberDAOImpl();
		int result = dao.insert2(mem);
		return result;
	}

	public ArrayList<MemhaveDTO> haveStock(String id){
		MemberDAO dao = new MemberDAOImpl();
		ArrayList<MemhaveDTO> memlist = dao.haveStock(id);
		return memlist;
	}
	@Override
	public int pointupdate(MemberDTO mem) {
		MemberDAOImpl dao = new MemberDAOImpl();
		int result = dao.pointupdate(mem);
		return result;
	}
	@Override
	public int pointupdate2(MemberDTO mem) {
		MemberDAOImpl dao = new MemberDAOImpl();
		int result = dao.pointupdate2(mem);
		return result;
	}

	
	@Override
	public int delete(String mem_id) {
		MemberDAOImpl dao = new MemberDAOImpl();
		int result = dao.delete(mem_id);
		return result;
	}
	
}