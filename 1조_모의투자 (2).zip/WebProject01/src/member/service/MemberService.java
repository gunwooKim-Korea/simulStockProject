package member.service;

import java.util.ArrayList;

import term.dto.TermDTO;
import member.dto.GainDTO;
import member.dto.MemberDTO;
import member.dto.MemhaveDTO;
import member.dto.TradeTop5DTO;
import member.dto.userHistoryDTO;

public interface MemberService {
	public MemberDTO login(String id, String pw);
	
	int insert(MemberDTO mem);
	int insert2(MemberDTO mem);
	
	int update(MemberDTO mem);
	
	public MemberDTO search(String id) ;
	
	int pointupdate(String id, int point);
	
	ArrayList<MemberDTO> getmemberList(String search,int page);
	int getTotal(String search);
	
	boolean idCheck(String mem_id);
	
	ArrayList<MemhaveDTO> haveStock(String id);
	
	int pointupdate(MemberDTO mem);
	int pointupdate2(MemberDTO mem);
	int delete(String mem_id);
	public ArrayList<userHistoryDTO> checkUserHistory(String id);

	public ArrayList<GainDTO> GainSearch(String id);
	
	public ArrayList<TradeTop5DTO> tradetop();
	
}