package member.dao;

import static fw.DBUtil.*;
import static fw.MemberQuery.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import member.dto.GainDTO;
import member.dto.MemberDTO;
import member.dto.MemhaveDTO;
import member.dto.TradeTop5DTO;
import member.dto.userHistoryDTO;
import fw.DBUtil;

public class MemberDAOImpl implements MemberDAO {

	@Override
	public int insert(MemberDTO mem) {
		Connection con = null;
		PreparedStatement ptmt = null;
		int result = 0;
		try {
			con = DBUtil.getConnection();
			ptmt = con.prepareStatement(MEMBER_INSERT);
			ptmt.setString(1, mem.getMem_id());
			ptmt.setString(2, mem.getPass());
			ptmt.setString(3, mem.getEmail());
			ptmt.setInt(4, mem.getPoint());

			result = ptmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(null, ptmt, con);
		}
		return result;
	}
	
	public ArrayList<TradeTop5DTO> tradetop(){
		ArrayList<TradeTop5DTO> list = new ArrayList<TradeTop5DTO>();
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;
		TradeTop5DTO tradetop = null;

		try {
			con = DBUtil.getConnection();
			ptmt = con.prepareStatement(TRADE_TOP5);

			rs = ptmt.executeQuery();

			while (rs.next()) {
				tradetop = new TradeTop5DTO(rs.getString(1), rs.getInt(2), rs.getInt(3));
				
				list.add(tradetop);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs, ptmt, con);
		}
		return list;
	}

	@Override
	public MemberDTO login(String id, String pw) {
		Connection con = null;
		PreparedStatement ptmt = null;
		String sql = MEMBER_LOGIN;
		ResultSet rs = null;
		MemberDTO member = null;

		try {
			con = DBUtil.getConnection();
			ptmt = con.prepareStatement(sql);

			ptmt.setString(1, id);
			ptmt.setString(2, pw);
			rs = ptmt.executeQuery();

			while (rs.next()) {
				// System.out.println("ddddttt");

				member = new MemberDTO(rs.getString(1), rs.getString(2),
						rs.getString(3), rs.getInt(4));
			}
			//
			// System.out.println(member.toString());
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs, ptmt, con);
		}
		return member;
	}

	@Override
	public int update(MemberDTO mem) {

		Connection con = null;
		PreparedStatement ptmt = null;
		int result = 0;
		ResultSet rs = null;
		try {
			//System.out.println(mem.getMem_id() + "id");
			con = DBUtil.getConnection();
			ptmt = con.prepareStatement(MEMBER_UPDATE);

			ptmt.setString(1, mem.getPass());
			ptmt.setString(2, mem.getEmail());

			ptmt.setString(3, mem.getMem_id());

			result = ptmt.executeUpdate();
		//	System.out.println(result + "�� �� ���� ����!!");
		} catch (SQLException e) {
			//System.out.println("�������");
			e.printStackTrace();
		} finally {
			DBUtil.close(rs, ptmt, con);
		}
		return result;
	}

	@Override
	public MemberDTO search(String id) {
		Connection con = null;
		PreparedStatement ptmt = null;

		ResultSet rs = null;
		MemberDTO member = null;

		try {
			con = DBUtil.getConnection();
			ptmt = con.prepareStatement(MEMBER_search);

			ptmt.setString(1, id);

			rs = ptmt.executeQuery();

			while (rs.next()) {
				//System.out.println("ddddttt");

				member = new MemberDTO(rs.getString(1), rs.getString(2),
						rs.getString(3), rs.getInt(4));
			}
			//
			// System.out.println(member.toString());
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs, ptmt, con);
		}
		return member;
	}

	@Override
	public int pointupdate(String id, int point) {
		Connection con = null;
		PreparedStatement ptmt = null;
		int result = 0;
		try {
			con = DBUtil.getConnection();
			ptmt = con.prepareStatement(MEMBER_POINTUPDATE);
			ptmt.setInt(1, point);
			ptmt.setString(2, id);

			result = ptmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(null, ptmt, con);
		}
		return result;
	}

	@Override
	public ArrayList<MemberDTO> getmemberList(String search, int page) {
		ArrayList<MemberDTO> termlist = new ArrayList<MemberDTO>();
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;
		MemberDTO mem = null;// �ϳ��� ���ڵ带 ���� ��ü - ���ڵ带 ��ȸ�ϸ鼭 �ϳ��� ����
								// �־�� �Ѵ�.
		// System.out.println("dao : "+search+" page : "+page);

		try {
			con = getConnection();
			int a = ((page - 1) * 15) + 1;
			int b = (page * 15);
			if (search == null || search.equals("null") || search.equals("")) { // �����ȸ
				ptmt = con.prepareStatement(MEM_SELECT);
				ptmt.setInt(1, a);
				ptmt.setInt(2, b);
				// System.out.println("�⺻!"+search+" "+page);
			} else if (search != null) {// search�۾�
				ptmt = con.prepareStatement(MEM_SEARCH);
				ptmt.setString(1, "%" + search + "%");
				ptmt.setInt(2, a);
				ptmt.setInt(3, b);

				// System.out.println("�˻���!!"+search+" "+page);
			}
			rs = ptmt.executeQuery();

			while (rs.next()) {
				mem = new MemberDTO(rs.getString(2), rs.getString(3),
						rs.getString(4), rs.getInt(5));
				termlist.add(mem);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs, ptmt, con);
		}
		return termlist;
	}

	public ArrayList<userHistoryDTO> checkUserHistory(String id) {
		ArrayList<userHistoryDTO> list = new ArrayList<userHistoryDTO>();
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;
		userHistoryDTO userHis = null;

		try {
			con = DBUtil.getConnection();
			ptmt = con.prepareStatement(MEM_USERHIS);

			ptmt.setString(1, id);

			rs = ptmt.executeQuery();

			while (rs.next()) {
				userHis = new userHistoryDTO(rs.getString(1), rs.getInt(2),
						rs.getInt(3), rs.getInt(4));
				list.add(userHis);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs, ptmt, con);
		}
		return list;
	}
	
	
	public ArrayList<GainDTO> GainSearch(String id) {
		ArrayList<GainDTO> list = new ArrayList<GainDTO>();
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;
		GainDTO gaindto = null;

		try {
			con = DBUtil.getConnection();
			ptmt = con.prepareStatement(SEARCH_GAIN);

			ptmt.setString(1, id);

			rs = ptmt.executeQuery();

			while (rs.next()) {
				gaindto = new GainDTO(rs.getString(1), 
						rs.getInt(2), 
						rs.getInt(3),
						rs.getDouble(4), 
						rs.getInt(5));
				
				
				list.add(gaindto);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs, ptmt, con);
		}
		return list;
	}

	@Override
	public int getTotal(String search) {
		int total = 0;
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;
		try {
			con = getConnection();
			if (search == null || search.equals("null") || search.equals("")) { // �����ȸ
				ptmt = con.prepareStatement(MEM_TOTAL);
			} else {// search�۾�
				ptmt = con.prepareStatement(MEM_SEARCHTOTAL);
				ptmt.setString(1, "%" + search + "%");
			}
			rs = ptmt.executeQuery();

			if (rs.next()) {
				total = rs.getInt(1);
				// System.out.println("��Ż! : " + total);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs, ptmt, con);
		}
		return total;
	}

	@Override
	public boolean idCheck(String mem_id) {

		Connection con = null;
		PreparedStatement ptmt = null;

		ResultSet rs = null;
		MemberDTO member = null;
		boolean state = false;

		try {
			con = getConnection();
			ptmt = con.prepareStatement(ID_CHECK);
			ptmt.setString(1, mem_id);
			rs = ptmt.executeQuery();

			if (rs.next()) {
				state = true;
			}
			// System.out.println(result);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(null, ptmt, con);
		}

		return state;
	}

	@Override
	public int insert2(MemberDTO mem) {
		Connection con = null;
		PreparedStatement ptmt = null;
		int result = 0;
		try {
			con = DBUtil.getConnection();
			ptmt = con.prepareStatement(MEMBER_INSERT2);
			ptmt.setString(1, mem.getMem_id());
			ptmt.setInt(2, mem.getPoint());

			result = ptmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(null, ptmt, con);
		}
		return result;
	}

	@Override
	public ArrayList<MemhaveDTO> haveStock(String id) {
		ArrayList<MemhaveDTO> list = new ArrayList<MemhaveDTO>();
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;
		MemhaveDTO mem = null;

		try {
			con = getConnection();

			ptmt = con.prepareStatement(MEM_HAVESTOCK);
			ptmt.setString(1, id);
			ptmt.setString(2, id);

			rs = ptmt.executeQuery();

			while (rs.next()) {
				mem = new MemhaveDTO(rs.getString(1), rs.getString(2),
						rs.getInt(3), rs.getInt(4), rs.getInt(5));
				list.add(mem);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs, ptmt, con);
		}
		return list;
	}

	@Override
	public int pointupdate(MemberDTO mem) {
		Connection con = null;
		PreparedStatement ptmt = null;
		int result = 0;
		ResultSet rs = null;
		try {
			con = DBUtil.getConnection();
			ptmt = con.prepareStatement(POINT_UPDATE);

			/*
			 * ptmt.setInt(1, mem.getPoint()); ptmt.setString(2, mem.getMem_id()
			 * );
			 */

			ptmt.setString(2, mem.getMem_id());
			ptmt.setInt(1, mem.getPoint());

			result = ptmt.executeUpdate();
		} catch (SQLException e) {
			System.out.println("�������");
			e.printStackTrace();
		} finally {
			DBUtil.close(rs, ptmt, con);
		}
		return getpoint(mem.getMem_id());
	}

	public int getpoint(String id) {
		int point = 0;
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;
		try {
			con = getConnection();
				ptmt = con.prepareStatement(REUPDATE);
				ptmt.setString(1, id);
			rs = ptmt.executeQuery();

			if (rs.next()) {
				point = rs.getInt(1);
				// System.out.println("��Ż! : " + total);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs, ptmt, con);
		}
		return point;
	}
	


	@Override
	public int pointupdate2(MemberDTO mem) {
		Connection con = null;
		PreparedStatement ptmt = null;
		int result = 0;
		ResultSet rs = null;
		try {
			con = DBUtil.getConnection();
			ptmt = con.prepareStatement(POINT_UPDATE2);

			/*
			 * ptmt.setInt(1, mem.getPoint()); ptmt.setString(2,
			 * mem.getMem_id());
			 */

			ptmt.setString(2, mem.getMem_id());
			ptmt.setInt(1, mem.getPoint());

			result = ptmt.executeUpdate();
		} catch (SQLException e) {
			System.out.println("�������");
			e.printStackTrace();
		} finally {
			DBUtil.close(rs, ptmt, con);
		}
		return result;

	}

	@Override
	public int delete(String mem_id) {
		Connection con = null;
		PreparedStatement ptmt = null;

		int result = 0;
		try {
			con = getConnection();
			ptmt = con.prepareStatement(MEMBER_DELETE);
			ptmt.setString(1, mem_id);
			result = ptmt.executeUpdate();
			ptmt = con.prepareStatement(MEMBER_DELETE2);
            ptmt.setString(1, mem_id);
			result = ptmt.executeUpdate();
			ptmt = con.prepareStatement(MEMBER_DELETE3);
			ptmt.setString(1, mem_id);
			result = ptmt.executeUpdate();
			ptmt = con.prepareStatement(MEMBER_DELETE4);
			ptmt.setString(1, mem_id);
			result = ptmt.executeUpdate();
			ptmt = con.prepareStatement(MEMBER_DELETE5);
			ptmt.setString(1, mem_id);
			result = ptmt.executeUpdate();
			ptmt = con.prepareStatement(MEMBER_DELETE6);
			ptmt.setString(1, mem_id);
			result = ptmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(null, ptmt, con);
		}
		return result;
	}
}
