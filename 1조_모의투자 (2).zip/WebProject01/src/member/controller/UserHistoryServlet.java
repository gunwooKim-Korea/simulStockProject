package member.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import member.dto.GainDTO;
import member.dto.MemhaveDTO;
import member.dto.userHistoryDTO;
import member.service.MemberService;
import member.service.MemberServiceImpl;
import stock.service.stockService;
import stock.service.stockServiceImpl;

@WebServlet(name = "userhistory", urlPatterns = { "/userhistory.do" })
public class UserHistoryServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		req.setCharacterEncoding("euc-kr");

		HttpSession sess = req.getSession();
		String id =(String)sess.getAttribute("id");

		stockService stockservice = new stockServiceImpl();
		MemberService memservice = new MemberServiceImpl();
		//System.out.println(id);
		int point = stockservice.pointCheck(id); //�ʱ��ں�
		int point2 = stockservice.pointCheck2(id);//��������Ʈ
		
		ArrayList<GainDTO> gainList = memservice.GainSearch(id);
	 	
	
		for (int i = 0; i < gainList.size(); i++) {
			GainDTO gain = gainList.get(i);
		}
		 
		ArrayList<userHistoryDTO> list = memservice.checkUserHistory(id);
		
		int sumPrice = 0;
		for (int i = 0; i < list.size(); i++) {
			userHistoryDTO user = list.get(i);
			sumPrice = sumPrice+user.getSum_price();
		}
		sumPrice = sumPrice + point2;//�����ں�
		 
		int gain = sumPrice-point;
		
		double gainRate = ((double)gain/(double)point)*100;//������ͷ�
		
		req.setAttribute("point", point);
		req.setAttribute("sumPrice", sumPrice);
		req.setAttribute("gainRate", gainRate);
		req.setAttribute("gain", gain);
		
		
		req.setAttribute("gainList", gainList);
		
		
		req.setAttribute("menupath", "../myPage/myPage_menu.jsp");
		req.setAttribute("viewpath", "../myPage/myPage_userHistory.jsp");

		RequestDispatcher rd = req
				.getRequestDispatcher("/layout/mainLayout.jsp");
		rd.forward(req, resp);

	}

}