package member.dto;

public class TradeTop5DTO {

	String crp_nm;
	int count;
	int cur_price;
	@Override
	public String toString() {
		return "TradeTop5DTO [crp_nm=" + crp_nm + ", count=" + count
				+ ", cur_price=" + cur_price + "]";
	}
	public TradeTop5DTO(String crp_nm, int count, int cur_price) {
		super();
		this.crp_nm = crp_nm;
		this.count = count;
		this.cur_price = cur_price;
	}
	public String getCrp_nm() {
		return crp_nm;
	}
	public void setCrp_nm(String crp_nm) {
		this.crp_nm = crp_nm;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getCur_price() {
		return cur_price;
	}
	public void setCur_price(int cur_price) {
		this.cur_price = cur_price;
	}


}
