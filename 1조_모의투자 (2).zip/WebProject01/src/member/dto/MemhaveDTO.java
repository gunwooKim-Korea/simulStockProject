package member.dto;

public class MemhaveDTO {

	String name;
	String stock_cd;
	int avg;
	int count;
	int price;
	public MemhaveDTO(){}
	public MemhaveDTO(String name, String stock_cd, int avg, int count, int price) {
		super();
		this.name = name;
		this.stock_cd = stock_cd;
		this.avg = avg;
		this.count = count;
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStock_cd() {
		return stock_cd;
	}
	public void setStock_cd(String stock_cd) {
		this.stock_cd = stock_cd;
	}
	public int getAvg() {
		return avg;
	}
	public void setAvg(int avg) {
		this.avg = avg;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "haveDTO [name=" + name + ", stock_cd=" + stock_cd + ", avg="
				+ avg + ", count=" + count + ", price=" + price + "]";
	}

	
	
}
