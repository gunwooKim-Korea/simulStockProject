select rcp_no,rpt_nm,rcp_dt from DISCLOSURE where stock_cd='000030' order by rcp_dt desc;

delete from DISCLOSURE where rcp_dt > '20170712';

select * from ADMINUPDATE ;

select * from buystock;

select rcp_no, rcp_dt from disclosure where stock_cd='000030' order by rcp_dt desc;

alter table stock drop column stock_name;


alter table stock drop column change_rate;
alter table stock drop column trade_val;
alter table stock drop column sum_price;


select * from stock;

