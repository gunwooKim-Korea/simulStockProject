package admin.dao;

import java.util.ArrayList;

import org.w3c.dom.Element;


public interface updateDAO {
	void insert(Element eElement);
	String getTagValue(String tag, Element eElement);
	public ArrayList<String> getCodeList();
	public void insertDate();
	public String getdate();
}










