package admin.service;

public interface updateService{
	public void updateStart(String date);
	public String getdate();
	public void insertDate();
} 
