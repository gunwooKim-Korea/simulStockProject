package admin.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import admin.service.updateService;
import admin.service.updateServiceImpl;

@WebServlet(name = "capital", urlPatterns = { "/capital.do"})
public class capitalUpdate extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

		String viewpath = request.getParameter("viewpath");
		String menupath = request.getParameter("menupath");
		String date = request.getParameter("date");
		
		//System.out.println("date : "+date);
		
		
		if(viewpath==null){
			viewpath="../admin/UpdateList.jsp";
		}
		if(menupath==null){
			menupath="../admin/admin_menu.jsp";
		}
		
		
		updateService service = new updateServiceImpl();
		service.updateStart(date);
		service.insertDate();
		
		request.setAttribute("viewpath", viewpath);
		request.setAttribute("menupath", menupath);
		//request.setAttribute("date", date);
		
		RequestDispatcher rd = request.getRequestDispatcher("/layout/mainLayout.jsp");
		rd.forward(request, response);
		
	}

}
