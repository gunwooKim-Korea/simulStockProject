package admin.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import member.dto.MemberDTO;
import member.service.MemberService;
import member.service.MemberServiceImpl;
import term.dto.TermDTO;

@WebServlet(name = "memlist", urlPatterns = { "/memlist.do" })
public class memberListServlet extends HttpServlet {
	// ��ü �μ� ��� ��ȸ, �μ� �˻�
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
	
		int page=1;
		String ck = req.getParameter("ck");	//previous, next, null
		int startpage = 1;
		String viewpath = req.getParameter("viewpath");
		String menupath = req.getParameter("menupath");
		
		////////////////////////////////////////////////////////////
		
				if(req.getParameter("page")!=null){
					page =Integer.parseInt(req.getParameter("page"));
				//	System.out.println("page : "+page);
					startpage=page;
					if(ck!=null){
						if(ck.equals("previous")&page!=1){
							page=page-5;
							startpage = page;
						}else if(ck.equals("next")){
							page=page+5;
							startpage=page;
						}
					}else{
						if((page%5)==0){startpage=page-4;}
						else if((page%5)!=1){startpage=page-(page%5)+1;}
					}
			}	

		////////////////////////////////////////////////////////////
				
		String search = req.getParameter("search");

		//System.out.println("������, �˻��� : "+page+" "+search);
		
		MemberService service = new MemberServiceImpl();
		ArrayList<MemberDTO> memlist = service.getmemberList(search, page);
		int TOTAL = service.getTotal(search);
		int check=0;
		
		if(viewpath==null){
			viewpath="../admin/memberList.jsp";
		}
		if(menupath==null){
			menupath="../admin/admin_menu.jsp";
		}
		
		/*if(memlist.size()<15){
			check=1;
		}*/
		//
		//System.out.println("���� : "+memlist+"\n"+startpage+" "+TOTAL+" "+search);
		
		// ������ ����
		req.setAttribute("check", check);
		req.setAttribute("memlist", memlist);
		req.setAttribute("startpage", startpage);
		req.setAttribute("viewpath", viewpath);
		req.setAttribute("menupath", menupath);
		req.setAttribute("TOTAL", TOTAL);
		req.setAttribute("search", search);
		//<a href="#" onclick="sendEmail(<%=dto.getEmail()%>)">
		// ��û������
		RequestDispatcher rd = req
				.getRequestDispatcher("/layout/mainLayout.jsp");
		rd.forward(req, resp);

	}

}
