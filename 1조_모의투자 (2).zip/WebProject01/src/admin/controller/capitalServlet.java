package admin.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import admin.service.updateService;
import admin.service.updateServiceImpl;

@WebServlet(name = "capitalview", urlPatterns = { "/capitalview.do"})
public class capitalServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

		String viewpath = request.getParameter("viewpath");
		String menupath = request.getParameter("menupath");
		
		if(viewpath==null){
			viewpath="../admin/UpdateList.jsp";
		}
		if(menupath==null){
			menupath="../admin/admin_menu.jsp";
		}
		
		updateService service = new updateServiceImpl();
		String updateday = service.getdate();
		
		
		request.setAttribute("viewpath", viewpath);
		request.setAttribute("menupath", menupath);
		request.setAttribute("updateday", updateday);
		
		RequestDispatcher rd = request.getRequestDispatcher("/layout/mainLayout.jsp");
		rd.forward(request, response);
		
	}

}
