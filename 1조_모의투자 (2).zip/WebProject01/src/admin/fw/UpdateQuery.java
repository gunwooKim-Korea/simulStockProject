package admin.fw;

public class UpdateQuery {
	public static String Disclosure_INSERT
	="insert into Disclosure values(?,?,?,?)";
	
	public static String GET_COMPANYCODE
	="select stock_cd from company";
	
	public static String DATE_INSERT
	="insert into ADMINUPDATE values((select count(*) from ADMINUPDATE)+1,to_char(sysdate,'yyyymmdd'))";
	
	public static String GET_DATE
	="select max(UPDATEDAY) from ADMINUPDATE";
	
}