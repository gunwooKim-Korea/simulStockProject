package fw;

public class MemberQuery {
	public static String MEMBER_LOGIN = 
			"select * from member where mem_id = ? and pass = ?";
	
	public static String MEMBER_INSERT
		="insert into member values(?,?,?,?)";
	
	public static String MEMBER_INSERT2
	="insert into capital values(?,?)";
	
	public static String MEMBER_UPDATE ="update member set pass=? , email=?"
			+ "where mem_id=?";
	
	public static String MEMBER_search
	="select * from member where mem_id = ?";
	
	//public static String MEM_SEARCH
	// ="select * from (select rownum count,member.* from member where mem_id like '%'||upper(?)||'%') where count between ? and ? and not mem_id = 'admin'";

	
	
	public static String MEMBER_POINTUPDATE
	="update member set point = ? where mem_id = ?";
	
	 public static String POINT_UPDATE ="update member set point=point+?"
	         + "where mem_id=?";
  
   public static String POINT_UPDATE2 ="update capital set point=point+?"
	         + "where mem_id=?";
   
   public static String MEMBER_DELETE
	= "delete from member where mem_id = ?";
	
	public static String MEM_SEARCH
	 ="select * from (select rownum count,member.* from member where mem_id like '%'||upper(?)||'%') where count between ? and ? ";
	
	public static String MEM_SELECT
	 ="select * from (select rownum count,member.* from member) where count between ? and ?";
	
	public static String MEM_TOTAL
	 ="select count(*) from member";
	
	public static String MEM_SEARCHTOTAL
	 ="select count(*) from member where mem_id like '%'||upper(?)||'%'";
	
	public static String ID_CHECK
	 ="select * from member where mem_id = ?";
	
	public static String MEM_HAVESTOCK
	 ="select c.crp_nm,a.t,a.av,hs.count,s.cur_price "+
	"from company c,havestock hs,stock s,(select company_id t, avg(buy_price) av from buystock where mem_id=? group by company_id) a "+
	"where c.stock_cd=a.t and hs.company_id=a.t and hs.mem_id=? and s.stock_code=a.t";

	public static String MEM_USERHIS
	="select A.COMPANY_ID,count,CUR_PRICE, A.COUNT*CUR_PRICE from STOCK,(SELECT COUNT,COMPANY_ID FROM HAVESTOCK WHERE MEM_ID = ?) A WHERE A.COMPANY_ID = STOCK.STOCK_CODE";

	 public static String SEARCH_GAIN
	 ="select cp.CRP_NM, (hs.count * bs.buy_price) , (hs.count * s.cur_price) as ,(((hs.count * s.cur_price)-(hs.count * bs.buy_price))/(hs.count * bs.buy_price))*100 ,((hs.count * s.cur_price)-(hs.count * bs.buy_price)) from havestock hs, buystock bs, stock s, company cp where hs.mem_id = bs.mem_id and bs.mem_id = ? and cp.STOCK_CD = s.STOCK_CODE and cp.STOCK_CD = bs.company_id and bs.company_id = hs.company_id";
	 public static String MEMBER_DELETE2
		= "delete from buystock where mem_id = ?";
	  public static String MEMBER_DELETE3
		= "delete from capital where mem_id = ?";
	  public static String MEMBER_DELETE4
		= "delete from havestock where mem_id = ?";
	  public static String MEMBER_DELETE5
		= "delete from sellstock where mem_id = ?";
	  public static String MEMBER_DELETE6
		= "delete from liketab where mem_id = ?";

	  public static String TRADE_TOP5
		= "select cmp.crp_nm, A.c, st.cur_price from company cmp,stock st,(select row_number() over (order by count(company_id) desc) rn,company_id,count(company_id) c from buystock group by company_id) A where A.rn<6 and cmp.stock_cd = A.company_id and A.company_id=st.stock_code";
	  public static String REUPDATE
	  ="select point from member where mem_id=?";

}