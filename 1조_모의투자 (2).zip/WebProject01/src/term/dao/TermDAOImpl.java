package term.dao;

import static fw.DBUtil.close;
import static fw.DBUtil.getConnection;
import static fw.TermQuery.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import term.dto.MeanDTO;
import term.dto.TermDTO;

public class TermDAOImpl implements TermDAO {
	
	@Override
	public ArrayList<TermDTO> getTermList(String search,int page){
		ArrayList<TermDTO> termlist = new ArrayList<TermDTO>();
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;
		TermDTO term = null;//�ϳ��� ���ڵ带 ���� ��ü - ���ڵ带 ��ȸ�ϸ鼭 �ϳ��� ����
		                    //                 �־�� �Ѵ�.
		//System.out.println("dao : "+search+" page : "+page);
		
		
		try {
			con = getConnection();
			int a = ((page-1)*15)+1;
			int b = (page*15);
			if(search==null ||search.equals("null")|| search.equals("")){	//�����ȸ
				ptmt = con.prepareStatement(TERM_SELECT);
				ptmt.setInt(1, a);
				ptmt.setInt(2, b);
				//System.out.println("�⺻!");
			}else if(search!=null){//search�۾�
				ptmt = con.prepareStatement(TERM_SEARCH);
				ptmt.setString(1, "%"+search+"%");
				ptmt.setInt(2, a);
				ptmt.setInt(3, b);

				//System.out.println("�˻���!!");
			}
			rs = ptmt.executeQuery();
			
			while(rs.next()){
				term = new TermDTO(rs.getInt(1),rs.getString(2),rs.getString(3));
				termlist.add(term);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			close(rs, ptmt, con);
		}
		return termlist;
	}
	
	
	public MeanDTO getTermMean(String termId){
		MeanDTO termdto = null;
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;

		try {
			con = getConnection();
		
				ptmt = con.prepareStatement(TERM_MEAN);
				ptmt.setString(1, termId);
			
			rs = ptmt.executeQuery();
			
			  if(rs.next()){
	               
	               String reple= rs.getString(2);
	               
	          /*    reple= reple.replace("&lt;", " ");
	              reple= reple.replace("/", " ");
	              reple= reple.replace("p&gt;", " ");*/
	               reple= reple.replace("&lt;p&gt;", " ");
	               reple= reple.replace("&lt;/p&gt;", " ");
	               reple= reple.replace("&lt;p /&gt;", " ");
	               
	               reple= reple.replace("src", " ");
	               
	               termdto = new MeanDTO(rs.getString(1),reple);
	            }
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			close(rs, ptmt, con);
		}
		return termdto;
	}


	@Override
	public int getTotal(String search) {
		int total = 0;
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;
		try {
			con = getConnection();
			if(search==null || search.equals("null")||search.equals("")){	//�����ȸ
				ptmt = con.prepareStatement(TERM_TOTAL);
			}else{//search�۾�
				ptmt = con.prepareStatement(TERM_SEARCHTOTAL);
				ptmt.setString(1, "%"+search+"%");
			}
			rs = ptmt.executeQuery();
			
			if(rs.next()){
				total = rs.getInt(1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			close(rs, ptmt, con);
		}
		return total;
	}
}








