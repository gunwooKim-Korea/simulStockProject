package news.dao;

import java.util.ArrayList;

import news.dto.NewsLinkDTO;


public interface NewsDAO {
	ArrayList<NewsLinkDTO> getNewsList();
}
