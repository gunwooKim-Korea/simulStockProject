package news.service;

import java.util.ArrayList;

import company.dao.CompanyDAO;
import company.dao.CompanyDAOImpl;
import company.dto.CompanyDTO;
import news.dao.NewsDAO;
import news.dao.NewsDAOImpl;
import news.dto.NewsLinkDTO;

public class NewsServiceImpl implements NewsService {

	@Override
	public ArrayList<NewsLinkDTO> getNewsList() {
		NewsDAO dao = new NewsDAOImpl();
		ArrayList<NewsLinkDTO> list = dao.getNewsList();
		return list;
		
	}

}
