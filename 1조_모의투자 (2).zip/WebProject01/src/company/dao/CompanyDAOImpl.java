package company.dao;

import static company.fw.companyQuery.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import twitter4j.QueryResult;
import twitter4j.Twitter;
import twitter4j.TwitterFactory;
import twitter4j.conf.ConfigurationBuilder;

import company.dto.CapitalInfoDTO;
import company.dto.CompanyDTO;
import company.dto.CompanyLikeDTO;
import company.dto.TwitDTO;

import fw.DBUtil;

public class CompanyDAOImpl implements CompanyDAO {

	@Override
	public ArrayList<CompanyDTO> getCompanyList(String search, int page) {
		ArrayList<CompanyDTO> list = new ArrayList<CompanyDTO>();
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;
		CompanyDTO company = null;
		try {
			con = DBUtil.getConnection();
			int a = ((page - 1) * 15) + 1;
			int b = (page * 15);
			if (search == null || search.equals("null") || search == "") {
				ptmt = con.prepareStatement(COMPANY_LIST);
				ptmt.setInt(1, a);
				ptmt.setInt(2, b);
			} else {
				ptmt = con.prepareStatement(COMPANY_SEARCH);
				ptmt.setString(1, "%" + search + "%");
				ptmt.setString(2, "%" + search + "%");
				ptmt.setInt(3, a);
				ptmt.setInt(4, b);
			}
			rs = ptmt.executeQuery();
			while (rs.next()) {

				company = new CompanyDTO(rs.getString(2), rs.getString(3),
						rs.getString(4), rs.getString(5), rs.getString(6),
						rs.getString(7), rs.getString(8), rs.getString(9),
						rs.getString(10), rs.getString(11), rs.getString(12),
						rs.getString(13), rs.getString(14), rs.getString(15),
						rs.getString(16), rs.getString(17));
				list.add(company);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			DBUtil.close(rs, ptmt, con);
		}

		return list;
	}

	@Override
	public CompanyDTO getCompanyDetail(String stock_id) {
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;
		CompanyDTO company = null;

		try {
			con = DBUtil.getConnection();
			ptmt = con.prepareStatement(COMPANY_DETAIL);
			ptmt.setString(1, stock_id);
			// System.out.println(stock_id + "2");
			rs = ptmt.executeQuery();
			//
			while (rs.next()) {
			     
				String ir = rs.getString(11);
                 
                 if(ir==null){
                    
                    ir="";
                 }
				
				company = new CompanyDTO(rs.getString(1), rs.getString(2),
						rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getString(8),
						rs.getString(9), rs.getString(10), ir,
						rs.getString(12), rs.getString(13), rs.getString(14),
						rs.getString(15), rs.getString(16));
			}
			// System.out.println(company.toString());
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			DBUtil.close(rs, ptmt, con);
		}

		return company;
	}

	// 0708 hr
	@Override
	public ArrayList<CapitalInfoDTO> getCapitalList(String stock_cd) {
		ArrayList<CapitalInfoDTO> list = new ArrayList<CapitalInfoDTO>();
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;
		CapitalInfoDTO capital = null;
		try {
			con = DBUtil.getConnection();

			ptmt = con.prepareStatement(CAPITAL_LIST);
			ptmt.setString(1, stock_cd);

			rs = ptmt.executeQuery();
			while (rs.next()) {

				capital = new CapitalInfoDTO(rs.getString(1), rs.getString(2),
						rs.getString(3));
				list.add(capital);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			DBUtil.close(rs, ptmt, con);
		}

		return list;
	}

	@Override
	public int getTotal(String search) {
		int total = 0;
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;
		try {
			con = DBUtil.getConnection();

			if (search == null || search.equals("null") || search == "") {
				ptmt = con.prepareStatement(COMPANY_TOTAL);
			} else {
				ptmt = con.prepareStatement(COMPANY_SEARCHTOTAL);
				ptmt.setString(1, "%" + search + "%");
				ptmt.setString(2, "%" + search + "%");
			}
			rs = ptmt.executeQuery();
			if (rs.next()) {
				total = rs.getInt(1);
			}
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			DBUtil.close(rs, ptmt, con);
		}

		return total;
	}

	@Override
	public int CompanylikeInsert(String id, String stock_id) {
		Connection con = null;
		PreparedStatement ptmt = null;
		int result = 0;
		try {
			con = DBUtil.getConnection();
			ptmt = con.prepareStatement(LIKE_INSERT);
			ptmt.setString(1, id + stock_id);
			ptmt.setString(2, id);
			ptmt.setString(3, stock_id);

			result = ptmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(null, ptmt, con);
		}
		return result;
	}

	@Override
	public int CompanylikeDelete(String id, String stock_id) {
		Connection con = null;
		PreparedStatement ptmt = null;
		int result = 0;
		try {
			con = DBUtil.getConnection();
			ptmt = con.prepareStatement(LIKE_DELETE);
			ptmt.setString(1, id + stock_id);

			result = ptmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(null, ptmt, con);
		}
		return result;
	}

	@Override
	public ArrayList<String> getLikeList(String mem_id) {
		ArrayList<String> list = new ArrayList<String>();
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;
		CompanyLikeDTO dto = null;
		try {
			con = DBUtil.getConnection();
			ptmt = con.prepareStatement(SEARCH_LIKELIST);
			ptmt.setString(1, mem_id);
			rs = ptmt.executeQuery();
			while (rs.next()) {
				dto = new CompanyLikeDTO(rs.getString(1), rs.getString(2),
						rs.getString(3));
				list.add(dto.getStock_cd());
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs, ptmt, con);
		}
		return list;
	}

	@Override
	public ArrayList<TwitDTO> getTwitter(String stock_id) {

		/* �ν��Ͻ� ���� */
		ConfigurationBuilder cb = new ConfigurationBuilder();
		cb.setDebugEnabled(true)
				.setOAuthConsumerKey("JO48sGKlLIqppX9WAkB0vEgoE")
				.setOAuthConsumerSecret(
						"3EFD5PKDnQWORkt6FvTCRvK7KAWe5U9O78xLZB6ruIs9tkxnlZ")
				.setOAuthAccessToken(
						"875521110703341568-gjd4daW5i8NnuqUrWFS0bGk5z6RCXPV")
				.setOAuthAccessTokenSecret(
						"LpLDEtNDHeywFBn9w6DHj6Zw5E0C8pmPOjuUJ0H4A0woQ");

		TwitterFactory tf = new TwitterFactory(cb.build());
		Twitter twitter = tf.getInstance();

		String name=getCompanyName(stock_id);
		
		//System.out.println("Ʈ���� �˻��� : "+name);
		
		/* �˻� */
		twitter4j.Query que = new twitter4j.Query(name);
		QueryResult result = null;

		int i = 0;
		ArrayList<TwitDTO> list = new ArrayList<TwitDTO>();

		try {
			result = twitter.search(que);

			for (twitter4j.Status status : result.getTweets()) {
				i++;
				TwitDTO dto = new TwitDTO(status.getUser().getScreenName(),
						status.getText());
				list.add(dto);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public String getCompanyName(String stock_id) {
		String name = "";
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;
		try {
			con = DBUtil.getConnection();
			ptmt = con.prepareStatement(COMPANY_SEARCHNAME);
			ptmt.setString(1, stock_id);
			rs = ptmt.executeQuery();

			if (rs.next()) {
				name = rs.getString(1);
			}
			
		} catch (SQLException e) {
	
			e.printStackTrace();
		} finally {
			DBUtil.close(rs, ptmt, con);
		}
	
		name = name.replace("(��)","");
		//System.out.println("���̸�ã�� : "+name);
		
		return name;													
	}
}
