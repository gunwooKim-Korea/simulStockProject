package company.dao;

import java.util.ArrayList;

import company.dto.CapitalInfoDTO;
import company.dto.CompanyDTO;
import company.dto.CompanyLikeDTO;
import company.dto.TwitDTO;

public interface CompanyDAO {
	ArrayList<CompanyDTO> getCompanyList(String search,int page);
	
	CompanyDTO getCompanyDetail(String stock_id);
	
	//0708 hr
	 ArrayList<CapitalInfoDTO> getCapitalList(String stock_cd);
	 int getTotal(String search);

	int CompanylikeInsert(String id, String stock_id);

	int CompanylikeDelete(String id, String stock_id);

	ArrayList<String> getLikeList(String mem_id);

	ArrayList<TwitDTO> getTwitter(String stock_id); 
}
