package company.dto;

public class TwitDTO {

	public String id;
	public String txt;

	public TwitDTO(String id, String txt) {
		this.id = id;
		this.txt = txt;
	}
}