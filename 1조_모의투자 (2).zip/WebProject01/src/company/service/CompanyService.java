package company.service;

import java.util.ArrayList;

import company.dto.CapitalInfoDTO;
import company.dto.CompanyDTO;
import company.dto.TwitDTO;


   public interface CompanyService{
	   ArrayList<CompanyDTO> getCompanyList(String search,int page);
	   CompanyDTO getCompanyDetail(String stock_id);
	   
	   //0708 hr
	   ArrayList<CapitalInfoDTO> getCapitalList(String search);
	   int getTotal(String search);
	   int CompanylikeInsert(String id, String stock_id);
	   int CompanylikeDelete(String id, String stock_id);
	   ArrayList<String> getLikeList(String mem_id);
	   ArrayList<TwitDTO> getTwitter(String mem_id);
   }

   