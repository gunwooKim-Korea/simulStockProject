package company.service;

import java.util.ArrayList;

import term.dao.TermDAO;
import term.dao.TermDAOImpl;
import company.dao.CompanyDAO;
import company.dao.CompanyDAOImpl;
import company.dto.CapitalInfoDTO;
import company.dto.CompanyDTO;
import company.dto.CompanyLikeDTO;
import company.dto.TwitDTO;

public class CompanyServiceImpl implements CompanyService {

	@Override
	public ArrayList<CompanyDTO> getCompanyList(String search,int page) {
		CompanyDAO dao = new CompanyDAOImpl();
		ArrayList<CompanyDTO> list = dao.getCompanyList(search,page);
		return list;
	}

	@Override
	public CompanyDTO getCompanyDetail(String stock_id) {
		CompanyDAO dao = new CompanyDAOImpl();
		CompanyDTO dto = dao.getCompanyDetail(stock_id);
		return dto;
	}

	
	
	//0708 hr
	@Override
	public ArrayList<CapitalInfoDTO> getCapitalList(String stock_cd) {
		CompanyDAO dao = new CompanyDAOImpl();
		ArrayList<CapitalInfoDTO> list = dao.getCapitalList(stock_cd);
		return list;
	}

	@Override
	public int getTotal(String search) {
		CompanyDAO dao = new CompanyDAOImpl();
		return dao.getTotal(search);
	}

	@Override
	public int CompanylikeInsert(String id, String stock_id) {
		CompanyDAO dao = new CompanyDAOImpl();
		return dao.CompanylikeInsert(id,stock_id);
	}

	@Override
	public int CompanylikeDelete(String id, String stock_id) {
		CompanyDAO dao = new CompanyDAOImpl();
		return dao.CompanylikeDelete(id,stock_id);
	}

	@Override
	public ArrayList<String> getLikeList(String mem_id) {
		CompanyDAO dao = new CompanyDAOImpl();
		ArrayList<String> list = dao.getLikeList(mem_id);
		return list;
	}

	@Override
	public ArrayList<TwitDTO> getTwitter(String stock_id) {
		CompanyDAO dao = new CompanyDAOImpl();
		ArrayList<TwitDTO> list = dao.getTwitter(stock_id);
		return list;
	}
  
}
