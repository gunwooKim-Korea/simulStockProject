package company.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import stock.dto.stockDTO;
import stock.service.stockService;
import stock.service.stockServiceImpl;
import company.dto.CapitalInfoDTO;
import company.dto.CompanyDTO;
import company.dto.TwitDTO;
import company.service.CompanyService;
import company.service.CompanyServiceImpl;


@WebServlet(name = "companydetail", urlPatterns = { "/companydetail.do" })
public class CompanyDetailServlet extends HttpServlet {

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String stock_id = request.getParameter("stock_id");
   
      CompanyDTO company = new CompanyDTO();
      CompanyService service = new CompanyServiceImpl();
       stockService stockservice = new stockServiceImpl();

      //������
      company = service.getCompanyDetail(stock_id);
      //��������
      ArrayList<CapitalInfoDTO> capitallist = service.getCapitalList(stock_id);
      //Ʈ����
      ArrayList<TwitDTO> twitList = service.getTwitter(stock_id);
      //�ְ�����
      ArrayList<stockDTO> stocklist = stockservice.getStockList(stock_id, 1);
      
      
      
      //request.setAttribute("menupath", "../company/company_menu.jsp");
      request.setAttribute("viewpath", "../company/company_info1.jsp");
      request.setAttribute("company", company);
      request.setAttribute("stock_id", stock_id);
      request.setAttribute("capitallist", capitallist);
      request.setAttribute("twitList", twitList);
      request.setAttribute("stocklist", stocklist);
   
   //   response.setContentType("text/html;charset=utf-8");
      

      
      RequestDispatcher rd = request.getRequestDispatcher("/layout/mainLayout02.jsp");
      rd.forward(request, response);
   }
}