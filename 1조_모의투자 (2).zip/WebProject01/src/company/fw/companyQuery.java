package company.fw;
//SQL�� �����ϴ� Ŭ���� - �����ӿ�ũ ������� ������Ʈ�� �ϴ� ��� XML���·� ����
public class companyQuery {

	/*
	public static String COMPANY_LIST =
			"select * from Company";
	// ="select * from (select rownum count,a.* from Company a) where count between ? and ?";
	
	public static String COMPANY_SEARCH
	 //=    "select * from company where crp_nm =? or stock_cd=?";
	 =    "select * from company where crp_nm like ? or stock_cd like ?";
	*/
	public static String COMPANY_DETAIL =
			"select * from company where stock_cd = ?";

	public static String COMPANY_LIST
	 ="select * from (select rownum count,Company.* from Company) where count between ? and ? ";
	
	public static String COMPANY_SEARCH
	 ="select * from (select rownum count,company.* from company where crp_nm like ? or stock_cd like ?) where count between ? and ?";
	
	public static String CAPITAL_LIST
	 =    "select rcp_no,rpt_nm,rcp_dt from DISCLOSURE where stock_cd=? order by rcp_dt desc";
	
	public static String COMPANY_TOTAL
	 ="select count(*) from company";
	
	public static String COMPANY_SEARCHTOTAL
	 ="select count(*) from company where crp_nm like ? or stock_cd like ?";
	

	public static String LIKE_INSERT
	= "insert into LIKETAB values(?,?,?)";
	
	public static String LIKE_DELETE
	= "delete from liketab where like_code=?";
	
	public static String SEARCH_LIKELIST
	= "select * from liketab where mem_id = ?";
	
	public static String COMPANY_SEARCHNAME
	= "select * from company where  STOCK_CD = ?";
	
	
}