import sys
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QAxContainer import *

STOCK_COLUMNS = ["등락률", "거래량", "종가", "외인순매수", "기관순매수", "개인순매수"]

class StockWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("DspStock")
        self.setGeometry(300, 300, 300, 150)

        #login
        self.kiwoom = QAxWidget("KHOPENAPI.KHOpenAPICtrl.1")
        self.kiwoom.dynamicCall("CommConnect()")

        #OpenAPI+ Event
        self.kiwoom.OnEventConnect.connect(self.eventConnect)
        self.kiwoom.OnReceiveTrData.connect(self.OnReceiveTrData)

    def analyze(self):
        kospi_codes = self.kiwoom.dynamicCall("GetCodeListByMarket(QString", ["0"]).split(';')


        kosdaq_codes = self.kiwoom.dynamicCall("GetCodeListByMarket(QString", ["10"]).split(';')

        all_codes = kospi_codes + kosdaq_codes;

        i=0
        for c in all_codes:
            if c:
                name = self.kiwoom.dynamicCall("GetMasterCodeName(QString)", [c])

                print(i, c, name)
                i+=1;

                # 일별주가정보 조회 테스트
                self.set("종목코드", "005930")
                self.set("종목일자", "20170705")
                self.set("표시구분", "0")

                self.kiwoom.dynamicCall("CommRqData(QString, QString, int, QString)", "005930_daily", "opt10086", 0, "0000")
    def OnReceiveTrData(self, ScrNo, RQName, TrCode, RecordName, PrevNext, DataLength, ErrorCode, Message, SplmMsg):
        if RQName == "005930_daily" :
           date = self.kiwoom.dynamicCall("CommGetData(Qstring, QString, QString, int, QString)", TrCode, "",
                                           RQName, 0, "날짜").strip()

           data = {
                'date':date
           }

           for col in STOCK_COLUMNS:

               data[col] = self.kiwoom.dynamicCall("CommGetData(QString, QString, QString, int, QString)", TrCode, "",
                                                    RQName, 0, col).strip()
           print(data)

    def set(self, *args):
        return self.kiwoom.dynamicCall("SetInputValue(QString, QString)", *args)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    pymon = StockWindow()
    pymon.show()
    sys.exit(app.exec_())


































