import sys
from PyQt5.QtWidgets import *
import Kiwoomtmp
import time
import cx_Oracle
from pandas import DataFrame

MARKET_KOSPI   = 0
MARKET_KOSDAQ  = 10

class PyMon:
    def __init__(self):
        self.kiwoom = Kiwoomtmp.Kiwoom()
        self.kiwoom.comm_connect()
        self.get_code_list()

    def get_code_list(self):
        self.kospi_codes = self.kiwoom.get_code_list_by_market(MARKET_KOSPI)
        self.kosdaq_codes = self.kiwoom.get_code_list_by_market(MARKET_KOSDAQ)


    def realRun(self, codelist):

        self.kiwoom.setRealReg("0101", "900050;000020;000030;000880;000660", "9001;10", "0")
        self.kiwoom.setRealReg("0101", "000880;000660;020150;003490;001800;005930;251270", ["10;9001;"], "0")

        while 1 :
            pass

        return 0

    def get_ohlcv(self, codelist, start):
        self.kiwoom.ohlcv = {'date': [], 'open': [], 'high': [], 'low': [], 'close': [], 'volum': []}

        now = time.localtime()

        cur_time = "%04d-%02d-%02d %02d:%02d:%02d" % (
        now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour, now.tm_min, now.tm_sec)
        time.sleep(0.4)
        df = DataFrame(self.kiwoom.ohlcv, columns=['date', 'open', 'high', 'low', 'close', 'volum'],
                       index=self.kiwoom.ohlcv['date'])

        return df

    def run_kosdaq(self):
        now = time.localtime()
        cur_time = "%04d-%02d-%02d %02d:%02d:%02d" % (now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour, now.tm_min, now.tm_sec)

        dt = "%04d%02d%02d" % (now.tm_year, now.tm_mon, now.tm_mday)
        print(dt)
        kosdaq_df = self.get_ohlcv(self.kosdaq_codes, dt)
        return kosdaq_df



    def run_kospi(self):
        now = time.localtime()
        cur_time = "%04d-%02d-%02d %02d:%02d:%02d" % (now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour, now.tm_min, now.tm_sec)

        dt = "%04d%02d%02d" % (now.tm_year, now.tm_mon, now.tm_mday)
        print(dt)
        kospi_df = self.get_ohlcv(self.kospi_codes, dt)
        return kospi_df

if __name__ == "__main__":
    app = QApplication(sys.argv)
    pymon = PyMon()
    pymon.realRun(pymon.kospi_codes + pymon.kosdaq_codes)

'''
        for x in codelist:
            cur_time = "%04d-%02d-%02d %02d:%02d:%02d" % (now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour, now.tm_min, now.tm_sec)
            print(x)
            self.kiwoom.set_input_value("종목코드", x)
            self.kiwoom.ohlcv['종목코드'].append(x)
#            self.kiwoom.set_input_value("기준일자", start)
            self.kiwoom.comm_rq_data("opt10001_req", "opt10001", 0, "0101")
            print(i)
            time.sleep(0.3)
            i +=1
            '''
 #           df = DataFrame(self.kiwoom.ohlcv, columns=['종목코드', '날짜', '최고가', '최저가', '현재가', '거래량'],
 #                          index=self.kiwoom.ohlcv['날짜'])

 #       return df