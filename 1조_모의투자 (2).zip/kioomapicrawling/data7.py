import sys
from PyQt5.QtWidgets import *
import Kiwoom7
import time
from pandas import DataFrame

MARKET_KOSPI   = 0
MARKET_KOSDAQ  = 10

class PyMon:
    def __init__(self):
        self.kiwoom = Kiwoom7.Kiwoom()
        self.kiwoom.comm_connect()
        self.get_code_list()

    def get_code_list(self):
        self.kospi_codes = self.kiwoom.get_code_list_by_market(MARKET_KOSPI)
        self.kosdaq_codes = self.kiwoom.get_code_list_by_market(MARKET_KOSDAQ)

    def get_ohlcv(self, codelist, start):
        self.kiwoom.ohlcv = {'date': [], 'open': [], 'high': [], 'low': [], 'close': [], 'volume': []}
        list2 = codelist[1:]
        x = 0
        for i in list2:
            print(i)
            x += 1
            print(x)
            self.kiwoom.set_input_value("종목코드", i)
#            self.kiwoom.set_input_value("기준일자", start)
#            self.kiwoom.set_input_value("수정주가구분", 1)
            self.kiwoom.comm_rq_data("opt10081_req", "opt10001", 0, "0101")
            time.sleep(0.35)

        df = DataFrame(self.kiwoom.ohlcv, columns=['open', 'high', 'low', 'close', 'volume'],
                       index=self.kiwoom.ohlcv['date'])
        return df

    def run(self):
        now = time.localtime()
        cur_time = "%04d%02d%02d" % (
        now.tm_year, now.tm_mon, now.tm_mday-1)

        df = self.get_ohlcv(self.kospi_codes, cur_time)
        print(df)
#        df = self.get_ohlcv(self.kosdaq_codes, cur_time)
#        print(df)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    pymon = PyMon()
    pymon.run()