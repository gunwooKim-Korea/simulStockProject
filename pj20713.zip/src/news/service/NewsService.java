package news.service;

import java.util.ArrayList;

import news.dto.NewsLinkDTO;

public interface NewsService {
	ArrayList<NewsLinkDTO> getNewsList();
}
