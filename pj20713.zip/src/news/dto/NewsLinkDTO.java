package news.dto;

public class NewsLinkDTO {
	String news_img_src;
	String news_link_text;
	String news_link_src;
	
	public NewsLinkDTO(){}

	
	
	public NewsLinkDTO(String news_img_src, String news_link_text,
			String news_link_src) {
		super();
		this.news_img_src = news_img_src;
		this.news_link_text = news_link_text;
		this.news_link_src = news_link_src;
	}



	public String getNews_img_src() {
		return news_img_src;
	}

	public void setNews_img_src(String news_img_src) {
		this.news_img_src = news_img_src;
	}

	public String getNews_link_src() {
		return news_link_src;
	}

	public void setNews_link_src(String news_link_src) {
		this.news_link_src = news_link_src;
	}

	public String getNews_link_text() {
		return news_link_text;
	}

	public void setNews_link_text(String news_link_text) {
		this.news_link_text = news_link_text;
	}

	
	}

	