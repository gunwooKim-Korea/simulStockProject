package news.dao;



import static news.fw.NewsQuery.NEWS_LIST;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;

import news.dto.NewsLinkDTO;
import fw.DBUtil;

public class NewsDAOImpl implements NewsDAO {

	@Override
	public ArrayList<NewsLinkDTO> getNewsList() {
		
		ArrayList<NewsLinkDTO> list = new ArrayList<NewsLinkDTO>();
		Connection con = null;
		PreparedStatement ptmt = null;
		ResultSet rs = null;
		NewsLinkDTO link = null;

		try {	
			con = DBUtil.getConnection();
			ptmt = con.prepareStatement(NEWS_LIST);
			int a = new Random().nextInt(1200);
			ptmt.setInt(1, a);
			ptmt.setInt(2, a+5);
		    rs= ptmt.executeQuery();
		while(rs.next()){
			link = new NewsLinkDTO(
					rs.getString(1),
					rs.getString(2),
					rs.getString(3));
				list.add(link);	
		}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs, ptmt, con);
		}
		return list;
	}
}
