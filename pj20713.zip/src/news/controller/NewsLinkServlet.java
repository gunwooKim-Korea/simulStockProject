package news.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import news.dto.NewsLinkDTO;
import news.service.NewsServiceImpl;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


@WebServlet(name = "newslink", urlPatterns = { "/newslink.do" })
public class NewsLinkServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		NewsServiceImpl service = new NewsServiceImpl();
		ArrayList<NewsLinkDTO> newslist = service.getNewsList();
		JSONArray newsjsonlist = new JSONArray();

		for (int i = 0; i < 4;i++) {
			JSONObject jsonobj = new JSONObject();
			jsonobj.put("imgsrc", newslist.get(i).getNews_img_src());
			jsonobj.put("newstitle", newslist.get(i).getNews_link_text());
			jsonobj.put("newslink", newslist.get(i).getNews_link_src());
		
			newsjsonlist.add(jsonobj);
		}
		

		JSONObject realjsonobj = new JSONObject();
		response.setContentType("application/json;charset=utf-8");
		response.setHeader("cache-control", "no-cache,no-store");
		PrintWriter pw = response.getWriter();
		pw.print(newsjsonlist.toJSONString());
	}
}