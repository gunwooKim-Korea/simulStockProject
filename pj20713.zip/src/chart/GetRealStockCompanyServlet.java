package chart;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import stock.dto.RealDataDTO;
import stock.service.stockServiceImpl;

@WebServlet("/chartcompany.do")
public class GetRealStockCompanyServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		String Stock_code = request.getParameter("Stock_code");
		stockServiceImpl service = new stockServiceImpl();
		ArrayList<RealDataDTO> reallist1 = service.getCompanyStock(Stock_code);
		/*
		 * ArrayList<RealDataDTO> reallist2 =
		 * service.getRealStock(cplist.get(new Random().nextInt()));
		 * ArrayList<RealDataDTO> reallist3 =
		 * service.getRealStock(cplist.get(new Random().nextInt()));
		 */
		JSONObject jsonobj = new JSONObject();
		JSONArray realjsonlist1 = new JSONArray();
		// JSONArray realjsonlist2 = new JSONArray();
		// JSONArray realjsonlist3 = new JSONArray();

		for (int i = 0; i < reallist1.size(); i++) {
			if (i % 2 == 0) {
				JSONArray graph1 = new JSONArray();
				// JSONArray graph2 = new JSONArray();
				// JSONArray graph3 = new JSONArray();
				String date = reallist1.get(i).getStock_id();
				String year = date.substring(0, 4);
				String month = date.substring(4, 6);
				String day = date.substring(6, 8);
				
				String dd = year+"/"+month+"/"+day;
				
				graph1.add(dd);
				graph1.add(Integer.parseInt(reallist1.get(i).getPrice()));
				/*
				 * graph2.add(reallist2.get(i).getNow());
				 * graph2.add(Integer.parseInt(reallist2.get(i).getPrice()));
				 * graph3.add(reallist3.get(i).getNow());
				 * graph3.add(Integer.parseInt(reallist3.get(i).getPrice()));
				 */realjsonlist1.add(graph1);
				// realjsonlist2.add(graph2);
				// realjsonlist3.add(graph3);
			}
		}
		JSONObject realjsonobj = new JSONObject();

		// realjsonobj.put("reallist", jsonobj);

		/* response.setHeader("cache-control", "no-cache,no-store"); */
		request.setAttribute("company", realjsonlist1.toJSONString());

		RequestDispatcher rd = request
				.getRequestDispatcher("/chart/chartpopup.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		stockServiceImpl service = new stockServiceImpl();
		ArrayList<RealDataDTO> real = service.getRealStock("003310");

		real.toString();
	}

}
