package chart;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import stock.dto.RealDataDTO;
import stock.service.stockServiceImpl;

@WebServlet("/chart.do")
public class GetRealStockServlet extends HttpServlet {
	ArrayList<String> cplist = new ArrayList<String>();
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		cplist.add("016600");
		cplist.add("006910");
		cplist.add("007370");
		cplist.add("008800");
		cplist.add("017510");
		cplist.add("017480");
		cplist.add("005290");
		cplist.add("007370");
		cplist.add("006730");
		cplist.add("003670");
		
		stockServiceImpl service = new stockServiceImpl();
		ArrayList<RealDataDTO> reallist1 = service.getRealStock(cplist.get(new Random().nextInt(10)));
/*		ArrayList<RealDataDTO> reallist2 = service.getRealStock(cplist.get(new Random().nextInt()));
		ArrayList<RealDataDTO> reallist3 = service.getRealStock(cplist.get(new Random().nextInt()));
*/
		
		JSONObject jsonobj = new JSONObject();
		JSONArray realjsonlist1 = new JSONArray();
//		JSONArray realjsonlist2 = new JSONArray();
//		JSONArray realjsonlist3 = new JSONArray();
		
		for (int i = 0; i < reallist1.size();i++) {
			JSONArray graph1 = new JSONArray();
//			JSONArray graph2 = new JSONArray();
//			JSONArray graph3 = new JSONArray();
			graph1.add(reallist1.get(i).getNow());
			graph1.add(Integer.parseInt(reallist1.get(i).getPrice()));
/*			graph2.add(reallist2.get(i).getNow());
			graph2.add(Integer.parseInt(reallist2.get(i).getPrice()));
			graph3.add(reallist3.get(i).getNow());
			graph3.add(Integer.parseInt(reallist3.get(i).getPrice()));

			
*/			realjsonlist1.add(graph1);
//			realjsonlist2.add(graph2);
//			realjsonlist3.add(graph3);
		}
		JSONObject realjsonobj = new JSONObject();

//		realjsonobj.put("reallist", jsonobj);
		response.setContentType("application/json;charset=utf-8");
		response.setHeader("cache-control", "no-cache,no-store");
		PrintWriter pw = response.getWriter();
		pw.print(realjsonlist1.toJSONString());
/*		pw.print(realjsonlist2.toJSONString());
		pw.print(realjsonlist3.toJSONString());
*/	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		stockServiceImpl service = new stockServiceImpl();
		ArrayList<RealDataDTO> real = service.getRealStock("003310");
		
		real.toString();
	}

}
