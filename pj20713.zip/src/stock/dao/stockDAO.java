package stock.dao;

import java.util.ArrayList;

import member.dto.MemberDTO;
import stock.dto.RealDataDTO;
import stock.dto.buyDTO;
import stock.dto.companyInfoDTO;
import stock.dto.haveDTO;
import stock.dto.sellDTO;
import stock.dto.stockDTO;


public interface stockDAO {
	public ArrayList<stockDTO> getStockList(String search,int page);
	int buyStock(buyDTO buy);
	public companyInfoDTO companyInfo(String Stock_name) ;
	public int haveStock(haveDTO have);
	public int search_have_count(String company_id, String mem_id);
	public int sellStock(sellDTO selldto);
	public stockDTO searchDTO(String stock_code);
	public ArrayList<haveDTO> haveAll();
	public int update(haveDTO havedto);
	public int update(String mem_id, int sum);
	public ArrayList<haveDTO> search_havestock(String mem_id);
	public int getTotal(String search);
	public ArrayList<RealDataDTO> getRealStock(String stock_id);
	public ArrayList<stockDTO> getStockLikeList(String search, int page,
			MemberDTO user);
	public int pointCheck(String mem_id);
	public int pointCheck2(String mem_id);
	
	public int delete_have_count(String company_id, String mem_id);
	public ArrayList<stockDTO> getStockList2(String search,int page);
	
	ArrayList<RealDataDTO> getCompanyStock(String stock_id);
}










