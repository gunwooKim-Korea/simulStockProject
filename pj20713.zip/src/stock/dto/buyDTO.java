package stock.dto;

public class buyDTO {
	
	String mem_id ;
	String company_id ;
	int buy_price ;
	

	int buy_count ;
	
	
	@Override
	public String toString() {
		return "buyDTO [ mem_id=" + mem_id
				+ ", company_id=" + company_id + ", buy_price=" + buy_price + ", buy_count=" + buy_count + "]";
	}
	

	public buyDTO(String id, String stock_code, int price2, int val2) {
		
		this.mem_id = id;
		this.company_id = stock_code;
		
		this.buy_price = price2;
		this.buy_count = val2;
		
		
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getCompany_id() {
		return company_id;
	}
	public void setCompany_id(String company_id) {
		this.company_id = company_id;
	}


	public int getBuy_price() {
		return buy_price;
	}
	public void setBuy_price(int buy_price) {
		this.buy_price = buy_price;
	}
	public int getBuy_count() {
		return buy_count;
	}
	public void setBuy_count(int buy_count) {
		this.buy_count = buy_count;
	}

}
