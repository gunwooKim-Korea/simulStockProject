package stock.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import member.dto.MemberDTO;
import member.service.MemberService;
import member.service.MemberServiceImpl;
import stock.dto.buyDTO;
import stock.dto.haveDTO;
import stock.dto.stockDTO;
import stock.service.stockService;
import stock.service.stockServiceImpl;

@WebServlet(name = "stock_popup", urlPatterns = { "/stock_popup.do" })
public class stock_popup extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse resp)
			throws ServletException, IOException {
		
		request.setCharacterEncoding("euc-kr");
		resp.setCharacterEncoding("euc-kr");

		String price2 = (String) request.getParameter("price");
		String id = (String) request.getParameter("id");
		String Stock_code = (String) request.getParameter("Stock_code");
		String val = (String) request.getParameter("val");
	
		String msg = null;
		int price = Integer.parseInt(price2);
		stockService service = new stockServiceImpl();
		int have = service.search_have_count(Stock_code, id);
		haveDTO havedto = new haveDTO(id, Stock_code, 1);
		

		MemberService service2 = new MemberServiceImpl();
		MemberDTO mem = service2.search(id);
		System.out.println(mem.toString());
		int point = mem.getPoint();
		System.out.println(point);
		stockDTO stock = service.searchDTO(Stock_code);
	
	//	System.out.println(price+","+point);
		
		if (have > 0) {
			if (point >price*Integer.parseInt(val) ) {
				
			//	System.out.println(price*Integer.parseInt(val));
				
				int sum = point - price*Integer.parseInt(val);
				int val2 = have + Integer.parseInt(val);
				buyDTO buydto = new buyDTO(id, Stock_code, price, Integer.parseInt(val));
				int result = service.buyStock(buydto);
				haveDTO havedto2 = new haveDTO(id, Stock_code, val2);
				int result2 = service.update(havedto2);
			/*	int result3 = service.pointresult(id, sum);*/
				service2.pointupdate(id, sum);
				msg = "���ڼ���1";
			//	System.out.println("********************"+id);
				ArrayList<haveDTO> havelist = service.search_havestock(id);
				request.setAttribute("havelist", havelist);
				
			}else{
				msg = "���ڽ���";
			}

		} else {
			
			if (point >price*Integer.parseInt(val) ) {
				
			int sum = point - price*Integer.parseInt(val);
			int val2 = have + Integer.parseInt(val);
			buyDTO buydto = new buyDTO(id, Stock_code, price, Integer.parseInt(val));
			int result = service.buyStock(buydto);
			haveDTO havedto2 = new haveDTO(id, Stock_code, val2);
			int result3 = service.update(havedto2);
			int result2 = service.haveStock(havedto2);
			
			
			service2.pointupdate(id, sum);
			msg = "���ڼ���2";
		//	System.out.println("********************"+id);
			ArrayList<haveDTO> havelist = service.search_havestock(id);
			request.setAttribute("havelist", havelist);
			
			}else{
				msg = "���ڽ���";
			}
		
		}
	
		request.setAttribute("msg", msg);
		
		
		
	
		 PrintWriter out = resp.getWriter();
		  String str="";
		   str = "<script language='javascript'>";
		   str += "opener.window.location.reload();";
		   str += "self.close();";  
		    str += "</script>";
		   out.print(str);
		   
		   RequestDispatcher rd = request
					.getRequestDispatcher("/stock/stock_result.jsp");
			rd.forward(request, resp);
		   
		   
	

	}

}
