package stock.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import stock.dto.stockDTO;
import stock.service.stockService;
import stock.service.stockServiceImpl;
import member.dto.MemberDTO;
import company.service.CompanyService;
import company.service.CompanyServiceImpl;

@WebServlet("/stocklikelist.do")
public class StockLikeListServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession sess = request.getSession();
        MemberDTO user = (MemberDTO)sess.getAttribute("user");
        System.out.println("1dsa");
        System.out.println(user.getMem_id());
		String state = request.getParameter("state");
		String search = request.getParameter("search");
		
		int page=1;
		String ck = request.getParameter("ck");	//previous, next, null
		int startpage = 1;
		
		////////////////////////////////////////////////////////////
		
				if(request.getParameter("page")!=null){
					page =Integer.parseInt(request.getParameter("page"));
				//	System.out.println("page : "+page);
					startpage=page;
					if(ck!=null){
						if(ck.equals("previous")&page!=1){
							page=page-5;
							startpage = page;
						}else if(ck.equals("next")){
							page=page+5;
							startpage=page;
						}
					}else{
						if((page%5)==0){startpage=page-4;}
						else if((page%5)!=1){startpage=page-(page%5)+1;}
					}
			}	

		////////////////////////////////////////////////////////////
				
        stockService service = new stockServiceImpl();
		ArrayList<stockDTO> stocklist = service.getStockLikeList(search, page, user);
		int TOTAL = service.getTotal(search);
		int check=0;
		if(stocklist.size()<15){
			check=1;
		}
		System.out.println("2dsa");
        System.out.println(user.getMem_id());
		
		request.setAttribute("menupath", "../stock/stock_menu.jsp");
		request.setAttribute("viewpath", "../stock/stock_view.jsp");
		request.setAttribute("stocklist", stocklist);
		request.setAttribute("state", state);
		request.setAttribute("search", search);
		request.setAttribute("startpage", 1);
		request.setAttribute("check", check);
		request.setAttribute("startpage", startpage);
		request.setAttribute("TOTAL", TOTAL);
		request.setAttribute("search", search);
		
		
		RequestDispatcher rd = request.getRequestDispatcher("/layout/mainLayout.jsp");
		rd.forward(request, response);
	}
}
