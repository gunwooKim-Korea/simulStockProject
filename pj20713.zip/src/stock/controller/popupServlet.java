package stock.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import member.service.MemberService;
import member.service.MemberServiceImpl;
import stock.dto.companyInfoDTO;
import stock.dto.stockDTO;
import stock.service.stockService;
import stock.service.stockServiceImpl;

@WebServlet(name = "popup", urlPatterns = { "/popup.do" })
public class popupServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		req.setCharacterEncoding("euc-kr");


		String Stock_code = req.getParameter("Stock_code");
		HttpSession sess = req.getSession();
		String id =(String)sess.getAttribute("id");

		
		String mem_id = req.getParameter("mem_id");
	

		companyInfoDTO info = new companyInfoDTO();
		stockService service = new stockServiceImpl();
		
		
		stockDTO dto = service.searchDTO(Stock_code);

		//System.out.println(Stock_code);
		//System.out.println(dto.getStock_name());
		
		info = service.companyInfo(dto.getStock_name());
		
		/*System.out.println("DDDD" + info.toString());
		System.out.println(info.getCeo_nm());
		System.out.println(id);	
		System.out.println(Stock_code);
		System.out.println(dto.getCur_price());
		*/
	
		req.setAttribute("info", info);
		req.setAttribute("Stock_code", Stock_code);
		req.setAttribute("id", id);
		req.setAttribute("price", dto.getCur_price());

		//System.out.println("dddd");

		RequestDispatcher rd = req.getRequestDispatcher("/stock/popup.jsp");
		rd.forward(req, resp);

	}

}