package stock.service;
import java.util.ArrayList;

import member.dto.MemberDTO;
import stock.dto.RealDataDTO;
import stock.dto.buyDTO;
import stock.dto.companyInfoDTO;
import stock.dto.haveDTO;
import stock.dto.sellDTO;
import stock.dto.stockDTO;
//DAO�� �޼ҵ带 ȣ���ϴ� ���� 
public interface stockService {

	ArrayList<stockDTO> getStockList(String search,int page);
	ArrayList<stockDTO> getStockList2(String search, int page);
	
	
	
	stockDTO searchDTO(String Stock_code);
	int buyStock(buyDTO buy);
	companyInfoDTO companyInfo(String Stock_name);
	int haveStock(haveDTO have);
	int search_have_count(String company_id, String mem_id);
	int sellStock(sellDTO selldto);
	ArrayList<haveDTO> haveAll();
	int update(haveDTO havedto);
	int pointresult(String mem_id, int sum);
	public ArrayList<haveDTO> search_havestock(String mem_id) ;
	public int getTotal(String search);
	ArrayList<RealDataDTO> getRealStock(String stock_id);
	ArrayList<stockDTO> getStockLikeList(String search, int page, MemberDTO user);
	
	public int pointCheck2(String mem_id);
	public int pointCheck(String mem_id);
	public int delete_have_count(String company_id, String mem_id);
	ArrayList<RealDataDTO> getCompanyStock(String stock_id);
}







