package stock.service;

import java.util.ArrayList;

import member.dto.MemberDTO;
import stock.dao.stockDAO;
import stock.dao.stockDAOImpl;
import stock.dto.RealDataDTO;
import stock.dto.buyDTO;
import stock.dto.companyInfoDTO;
import stock.dto.haveDTO;
import stock.dto.sellDTO;
import stock.dto.stockDTO;

public class stockServiceImpl implements stockService {

	
	public ArrayList<stockDTO> getStockList(String search,int page) {
		stockDAO dao = new stockDAOImpl();
		ArrayList<stockDTO> list = dao.getStockList(search,page);	
		return list;
	}
	public ArrayList<stockDTO> getStockList2(String search,int page) {
		stockDAO dao = new stockDAOImpl();
		ArrayList<stockDTO> list = dao.getStockList2(search,page);	
		return list;
	}
	public int pointCheck(String mem_id) {
		int result = 0;
		stockDAO dao = new stockDAOImpl();
		result = dao.pointCheck(mem_id);
		return result;
	}
	public int pointCheck2(String mem_id) {
		int result = 0;
		stockDAO dao = new stockDAOImpl();
		result = dao.pointCheck2(mem_id);
		return result;
	}


	public int delete_have_count(String company_id, String mem_id) {
		int result = 0;
		stockDAO dao = new stockDAOImpl();
		result = dao.delete_have_count(company_id ,mem_id);
		return result;
	}

	public int buyStock(buyDTO buy) {
		stockDAO dao = new stockDAOImpl();
		int result = dao.buyStock(buy);
			
		return result;
	}


	@Override
	public companyInfoDTO companyInfo(String Stock_name) {
		stockDAO dao = new stockDAOImpl();
		companyInfoDTO info = dao.companyInfo(Stock_name);
		return info;
	}


	@Override
	public int haveStock(haveDTO have) {
		int result =0;
		stockDAO dao = new stockDAOImpl();
		result = dao.haveStock(have);
		return result;
	}


	@Override
	public int search_have_count(String company_id, String mem_id) {
		int result = 0;
		stockDAO dao = new stockDAOImpl();
		result = dao.search_have_count(company_id ,mem_id);
		return result;
	}
	
	public ArrayList<haveDTO> search_havestock(String mem_id) {
		stockDAO dao = new stockDAOImpl();
		ArrayList<haveDTO> havelist = dao.search_havestock(mem_id);
		return havelist;
	}


	@Override
	public int sellStock(sellDTO selldto) {
		int result = 0;
		stockDAO dao = new stockDAOImpl();
		result = dao.sellStock(selldto);
		return result;
	}


	@Override
	public stockDTO searchDTO(String Stock_code) {
		stockDAO dao = new stockDAOImpl();
		stockDTO dto = dao.searchDTO(Stock_code);
		return dto;
	}


	@Override
	public ArrayList<haveDTO> haveAll() {
		stockDAO dao = new stockDAOImpl();
		ArrayList<haveDTO> list = dao.haveAll();	
		return list;
	}


	@Override
	public int update(haveDTO havedto) {
		int result = 0;
		stockDAO dao = new stockDAOImpl();
		result = dao.update(havedto);
		return result;
	}


	@Override
	public int pointresult(String mem_id, int sum) {
		int result = 0;
		stockDAO dao = new stockDAOImpl();
		result = dao.update(mem_id,sum);
		return result;
	}
	public int getTotal(String search) {
		stockDAO dao = new stockDAOImpl();
		return dao.getTotal(search);
	}


	@Override
	public ArrayList<RealDataDTO> getRealStock(String stock_id) {
		stockDAO dao = new stockDAOImpl();
		ArrayList<RealDataDTO> arry = dao.getRealStock(stock_id);
		return arry;
	}


	@Override
	public ArrayList<stockDTO> getStockLikeList(String search, int page,
			MemberDTO user) {
		stockDAO dao = new stockDAOImpl();
		ArrayList<stockDTO> list = dao.getStockLikeList(search,page, user);	
		return list;
	}

	@Override
	public ArrayList<RealDataDTO> getCompanyStock(String stock_id) {
		stockDAO dao = new stockDAOImpl();
		ArrayList<RealDataDTO> arry = dao.getCompanyStock(stock_id);
		return arry;
	}





}









