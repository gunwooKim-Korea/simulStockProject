package developer.dto;


public class developerDTO {
	String name;
	String kname;
	String birth;
	String email;
	String sns;
	String phone;
	String addr;
	
	
	@Override
	public String toString() {
		return "developerDTO [name=" + name + ", kname=" + kname + ", birth="
				+ birth + ", email=" + email + ", sns=" + sns + ", phone="
				+ phone + ", addr=" + addr + "]";
	}

	public developerDTO(){
		
	}
	
	public developerDTO(String name, String kname, String birth, String email,
			String sns, String phone, String addr) {
		super();
		this.name = name;
		this.kname = kname;
		this.birth = birth;
		this.email = email;
		this.sns = sns;
		this.phone = phone;
		this.addr = addr;
	}



	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getBirth() {
		return birth;
	}

	public void setBirth(String birth) {
		this.birth = birth;
	}

	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSns() {
		return sns;
	}
	public void setSns(String sns) {
		this.sns = sns;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}

	public String getKname() {
		return kname;
	}

	public void setKname(String kname) {
		this.kname = kname;
	}

}