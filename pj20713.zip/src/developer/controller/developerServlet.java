package developer.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import developer.dto.developerDTO;
import developer.service.devService;
import developer.service.devServiceImpl;

@WebServlet(name = "developer", urlPatterns = { "/developer.do"})
public class developerServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

		//System.out.println("������~");
		String name = request.getParameter("name");
		
		//System.out.println("name : "+name);

		devService service = new devServiceImpl();
		developerDTO developer = service.getdev(name);
		
		request.setAttribute("viewpath", "../team/teammain.jsp");
		request.setAttribute("developer", developer);
		
		RequestDispatcher rd = request.getRequestDispatcher("/layout/mainLayout02.jsp");
		rd.forward(request, response);
		
	}

}
