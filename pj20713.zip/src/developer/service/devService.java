package developer.service;

import developer.dto.developerDTO;

public interface devService {

	developerDTO getdev(String name);

}
