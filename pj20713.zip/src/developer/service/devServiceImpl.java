package developer.service;

import developer.dao.devDAO;
import developer.dao.devDAOImpl;
import developer.dto.developerDTO;

public class devServiceImpl implements devService {

	@Override
	public developerDTO getdev(String name) {
		devDAO dao = new devDAOImpl();
		return dao.getdev(name);
	}

}
