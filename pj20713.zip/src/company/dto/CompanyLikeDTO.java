package company.dto;

public class CompanyLikeDTO {
	String likecode;
	String mem_id;
	String stock_cd;
	public CompanyLikeDTO(String likecode, String mem_id, String stock_cd) {
		super();
		this.likecode = likecode;
		this.mem_id = mem_id;
		this.stock_cd = stock_cd;
	}
	public String getLikecode() {
		return likecode;
	}
	public void setLikecode(String likecode) {
		this.likecode = likecode;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getStock_cd() {
		return stock_cd;
	}
	public void setStock_cd(String stock_cd) {
		this.stock_cd = stock_cd;
	}
	@Override
	public String toString() {
		return "MemberLikeDTO [likecode=" + likecode + ", mem_id=" + mem_id
				+ ", stock_cd=" + stock_cd + "]";
	}
}
