package company.dto;

public class CapitalInfoDTO {
	String rcp_no;
	String rpt_nm;
	String rcp_dt;
	
	public CapitalInfoDTO(){}
	public CapitalInfoDTO(String rcp_no, String rpt_nm, String rcp_dt) {
		super();
		this.rcp_no = rcp_no;
		this.rpt_nm = rpt_nm;
		this.rcp_dt = rcp_dt;
	}
	public String getRcp_no() {
		return rcp_no;
	}
	public void setRcp_no(String rcp_no) {
		this.rcp_no = rcp_no;
	}
	public String getRpt_nm() {
		return rpt_nm;
	}
	public void setRpt_nm(String rpt_nm) {
		this.rpt_nm = rpt_nm;
	}
	public String getRcp_dt() {
		return rcp_dt;
	}
	public void setRcp_dt(String rcp_dt) {
		this.rcp_dt = rcp_dt;
	}
	
	
}
