package company.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import company.service.CompanyService;
import company.service.CompanyServiceImpl;

@WebServlet(name = "Companylike", urlPatterns = { "/Companylike.do" })
public class CompanyLikeServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// System.out.println("DSFAasdfasdf");
		String stock_id = request.getParameter("stock_id");
		//String ck = request.getParameter("ck");
		
		HttpSession sess = request.getSession();
		String id = (String) sess.getAttribute("id");

		System.out.println("���� �ڵ� : " + stock_id + " ���̵�  : " + id);
		//System.out.println(ck+" = > �̹���");
		boolean ck = request.getParameter("ck").matches("/WebProject01/images/good02.png");	//
		CompanyService service = new CompanyServiceImpl();

		System.out.println(request.getParameter("ck"));
		System.out.println(ck);
		
		if(ck){
		int result = service.CompanylikeInsert(id,stock_id);
			System.out.println(result);
		}
		else{
			int result = service.CompanylikeDelete(id,stock_id);
		}
	}
}