package admin.dao;

import static admin.fw.UpdateQuery.Disclosure_INSERT;
import static admin.fw.UpdateQuery.GET_COMPANYCODE;
import static fw.DBUtil.close;
import static fw.DBUtil.getConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class updateDAOImpl implements updateDAO {
	
	public void insert(Element eElement) {
		Connection con = null;
		PreparedStatement ptmt = null;

		int result = 0;

		try {
			con = getConnection();
			ptmt = con.prepareStatement(Disclosure_INSERT);

			if (getTagValue("rcp_no", eElement)!=null) {
				ptmt.setString(1,  getTagValue("rcp_no", eElement));
				ptmt.setString(2, getTagValue("crp_cd", eElement));
				ptmt.setString(3, getTagValue("rcp_dt", eElement));
				ptmt.setString(4, getTagValue("rpt_nm", eElement));

				result = ptmt.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(null, ptmt, con);
		}
		// return result;
	}
	
	// tag���� ������ �������� �޼ҵ�
	public String getTagValue(String tag, Element eElement) {
		
		if(eElement.getElementsByTagName(tag).item(0)
				.getChildNodes()!=null){
		NodeList nlList = eElement.getElementsByTagName(tag).item(0)
				.getChildNodes();
		
		Node nValue = (Node) nlList.item(0);
		if (nValue == null)
			return null;
		return nValue.getNodeValue();
		}
		else{return null;}
	}


	public ArrayList<String> getCodeList() {

		Connection con = null;
		PreparedStatement ptmt = null;

		ResultSet rs = null;
		ArrayList<String> result = new ArrayList<String>();

		try {
			con = getConnection();
			ptmt = con
					.prepareStatement(GET_COMPANYCODE);
			rs = ptmt.executeQuery();

			while (rs.next()) {
				String str = rs.getString(1);
				result.add(str);
			}
			
			System.out.println("������! : " + result.size());
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(null, ptmt, con);
		}

		return result;
	}


}
