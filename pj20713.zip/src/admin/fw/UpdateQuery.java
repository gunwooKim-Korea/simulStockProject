package admin.fw;

public class UpdateQuery {
	public static String Disclosure_INSERT
	="insert into Disclosure values(?,?,?,?)";
	
	public static String GET_COMPANYCODE
	="select stock_cd from company";
	
}