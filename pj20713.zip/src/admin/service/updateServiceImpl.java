package admin.service;

import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import admin.dao.updateDAO;
import admin.dao.updateDAOImpl;

//��������//
public class updateServiceImpl implements updateService {

	public void updateStart(String date) {

		updateDAO dao = new updateDAOImpl();
		
		ArrayList<String> codelist = dao.getCodeList();
		System.out.println(codelist.get(711));
		System.out.println(codelist.get(714));
		int page = 1; // ������ �ʱⰪ

		System.out.println(codelist.get(page));

		try {
			while (true) {
				String com_cd="";

				 System.out.println("��������!!!!!! "+page +" �ڵ�!!!!! : "+codelist.get(page));
				 
				try{
				 com_cd = codelist.get(page);
				}catch(Exception e){System.out.println("����!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
				}
				String url =
						"http://dart.fss.or.kr/api/search.xml?auth=8717f2fc84d1d1acb18d1a3bf7918a43ec119d81&start_dt="+date+"&page_set=3000&crp_cd="+com_cd;

				DocumentBuilderFactory dbFactoty = DocumentBuilderFactory
						.newInstance();
				DocumentBuilder dBuilder = dbFactoty.newDocumentBuilder();
				Document doc = dBuilder.parse(url);

				// root tag
				doc.getDocumentElement().normalize();
				System.out.println("Root element :"
						+ doc.getDocumentElement().getNodeName());

				// �Ľ��� tag
				NodeList nList = doc.getElementsByTagName("list");
				System.out.println("�Ľ��� ����Ʈ �� : " + nList.getLength());

				for (int temp = 0; temp < nList.getLength(); temp++) {
					Node nNode = nList.item(temp);
					if (nNode.getNodeType() == Node.ELEMENT_NODE) {

						Element eElement = (Element) nNode;
						Thread.sleep(70);
						
						dao.insert(eElement);
						System.out.println("######################");
						// System.out.println(eElement.getTextContent());
						System.out.println("��ȣ  : "
								+ dao.getTagValue("rcp_no", eElement));
						System.out.println("����  : "
								+ dao.getTagValue("rpt_nm", eElement));

					} // if end

				}
				page += 1;
				System.out.println("page number : " + page);

			} // while end

		} catch (Exception e) {
			e.printStackTrace();
		} // try~catch end
		
	} // main end
} // class end
