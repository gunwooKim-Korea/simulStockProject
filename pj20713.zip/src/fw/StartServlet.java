package fw;


import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import member.dto.MemhaveDTO;
import member.dto.TradeTop5DTO;
import member.service.MemberService;
import member.service.MemberServiceImpl;

@WebServlet(name = "start", urlPatterns = { "/start.do" })
public class StartServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//�׷����۾�
		
		//�α���x -> �ŷ��� ���� �ְ� Top5  ���
		
		//�α���o -> �����ְ� / �����ְ� ���
		
		
	    HttpSession sess = request.getSession();
	    String id =(String) sess.getAttribute("id");
	    String ck = (String) request.getParameter("ck");
	    MemberService service = new MemberServiceImpl();
	    
	    ArrayList<MemhaveDTO> list = service.haveStock(id);
	    ArrayList<TradeTop5DTO> list2 = service.tradetop();
		
	    System.out.println(list2.size());
	    request.setAttribute("havelist", list);
	    request.setAttribute("tradelist", list2);
	    request.setAttribute("ck", ck);
	    
		RequestDispatcher rd = request.getRequestDispatcher("/Home.jsp");
		rd.forward(request, response);
	}

}