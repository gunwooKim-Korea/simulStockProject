package member.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import member.dto.MemberDTO;
import member.service.MemberService;
import member.service.MemberServiceImpl;


@WebServlet(name = "pointupdate", urlPatterns = { "/pointupdate.do" })
public class PointUpdateServlet extends HttpServlet {
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	   request.setCharacterEncoding("euc-kr");
	   
	   response.setContentType("text/html;charset=euc-kr");
		PrintWriter pw = response.getWriter();
		
		String mem_id = request.getParameter("mem_id");
	    String pass = request.getParameter("pass");
	    String email = request.getParameter("email");
		int point = (Integer.parseInt(request.getParameter("point")));
		
		/*
		System.out.println(mem_id);
		System.out.println(point);
		*/
		
		MemberDTO mem = new MemberDTO(mem_id, pass, email, point);
		
		System.out.println(mem+"!!!!!!!!!!!!!!!!!!!!!!!!!");
		
		
		MemberService service = new MemberServiceImpl();
		
		int result = service.pointupdate(mem);
		int result2 = service.pointupdate2(mem);
		System.out.println(result+"���1");
		System.out.println(result2+"���2");
		
		System.out.println("��������!!!!!!");
		
		request.setAttribute("viewpath", "../myPage/mypage_payment.jsp");
        request.setAttribute("menupath", "../myPage/myPage_menu.jsp");
		RequestDispatcher rd = request
				.getRequestDispatcher("/layout/mainLayout.jsp");
		rd.forward(request, response);
		
		/*response.sendRedirect("/WebProject01/memlist.do");*/
	}

}
