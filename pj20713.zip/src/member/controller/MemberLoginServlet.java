package member.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import member.dto.MemberDTO;
import member.dto.MemhaveDTO;
import member.service.MemberService;
import member.service.MemberServiceImpl;

@WebServlet(name = "login", urlPatterns = { "/login.do" })
public class MemberLoginServlet extends HttpServlet {
   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      
      String id = request.getParameter("id");
      String pw = request.getParameter("pass");
      String chk = request.getParameter("member_id_save");
      HttpSession sess = request.getSession();
      sess.setAttribute("id", id);

      MemberService service = new MemberServiceImpl();
      MemberDTO user = service.login(id, pw);
      String ck;
      if(user!=null){
    	  ck="false";
    	  System.out.println(user);
      }else{
    	  ck="true";
    	  System.out.println("��й�ȣ �Ǵ� ���̵� Ȯ��");
      }
      sess.setAttribute("user", user);
      request.setAttribute("user", user);
      request.setAttribute("ck", ck);

      ArrayList<MemhaveDTO> list = service.haveStock(id);


      sess.setAttribute("havelist", list);

      RequestDispatcher rd =
            request.getRequestDispatcher("start.jsp");
      rd.forward(request, response);

   }

}