package member.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import member.service.MemberService;
import member.service.MemberServiceImpl;


@WebServlet(name = "memdelete", urlPatterns = { "/memdelete.do" })
public class MemberDeleteServlet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		req.setCharacterEncoding("euc-kr");
		resp.setContentType("text/html;charset=euc-kr");
		PrintWriter pw = resp.getWriter();
			
		String mem_id = req.getParameter("mem_id");
		MemberService service = new MemberServiceImpl();
		int result = service.delete(mem_id);
		System.out.println(result+"�����Ϸ�");
		
		resp.sendRedirect("/WebProject01/memlist.do");
		
	
				
	}
	
}
