package member.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import member.dto.MemhaveDTO;
import member.service.MemberService;
import member.service.MemberServiceImpl;
import stock.service.stockService;
import stock.service.stockServiceImpl;

@WebServlet(name = "Memhavestock", urlPatterns = { "/Memhavestock.do" })
public class HaveStockServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		req.setCharacterEncoding("euc-kr");

		String Stock_code = req.getParameter("Stock_code");
		HttpSession sess = req.getSession();
		String id =(String)sess.getAttribute("id");

		MemberService service = new MemberServiceImpl();

		ArrayList<MemhaveDTO> list = service.haveStock(id);


		req.setAttribute("havelist", list);
		req.setAttribute("Stock_code", Stock_code);
		req.setAttribute("id", id);
		
		
		
		req.setAttribute("menupath", "../myPage/myPage_menu.jsp");
		req.setAttribute("viewpath", "../myPage/myPage_stockHistory.jsp");

		RequestDispatcher rd = req
				.getRequestDispatcher("/layout/mainLayout.jsp");
		rd.forward(req, resp);

	}

}