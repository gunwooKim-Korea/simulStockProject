package member.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import member.dto.MemberDTO;
import member.service.MemberService;
import member.service.MemberServiceImpl;

@WebServlet(name = "pointajax", urlPatterns = { "/pointajax.do" })
public class PointAjaxServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("euc-kr");

		response.setContentType("text/plain;charset=euc-kr");
		PrintWriter pw = response.getWriter();
		HttpSession sess = request.getSession();
		
		String id = (String) sess.getAttribute("id");
		String pass = (String) sess.getAttribute("pass");
	    String email = (String) sess.getAttribute("email");
		int point = (Integer.parseInt(request.getParameter("point")));
		System.out.println(id + "�� ����Ʈ : "+point);

	    
		MemberDTO mem = new MemberDTO(id, pass, email, point);

		System.out.println(mem + "!!!!!!!!!!!!!!!!!!!!!!!!!");

		MemberService service = new MemberServiceImpl();
		int result = service.pointupdate(mem);
		int result2 = service.pointupdate2(mem);
		System.out.println(result+"���1");
		System.out.println(result2+"���2");

		response.setHeader("cache-control", "no-cache,no-store");
	
		pw.print(result);
	}

}
