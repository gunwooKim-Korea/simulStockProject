package member.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import member.service.MemberService;
import member.service.MemberServiceImpl;

@WebServlet(name = "idcheckajax", urlPatterns = { "/idcheck_ajax.do" })
public class IdCheckAjaxServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
	
		
		
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
						
		resp.setHeader("cache-control", "no-cache,no-store");
		
		PrintWriter pw = resp.getWriter();
		
		String mem_id = req.getParameter("mem_id");
		
		MemberService service = new MemberServiceImpl();
		boolean state = service.idCheck(mem_id);
        System.out.println(state+"state��");
		String msg = "";
		
		if(!state){
			msg="��� ������ ���̵� �Դϴ�";
		}else{
			msg="�̹� ������� ���̵� �Դϴ�";
		}
		
		pw.print(msg);
		
		
	}
	
}
