package member.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import member.dto.MemberDTO;
import member.service.MemberService;
import member.service.MemberServiceImpl;


@WebServlet(name = "update", urlPatterns = { "/update.do" })
public class MemberUpdateServelt extends HttpServlet {
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	   request.setCharacterEncoding("euc-kr");
	   
	   response.setContentType("text/html;charset=euc-kr");
		PrintWriter pw = response.getWriter();
		
		String mem_id = request.getParameter("mem_id");
		String pass = request.getParameter("pass");
		String email = request.getParameter("email");
		System.out.println(mem_id);
		System.out.println(pass);
		System.out.println(email);
		
		MemberDTO mem = new MemberDTO(mem_id, pass, email);
		System.out.println(mem);
		System.out.println(mem);
		
		MemberService service = new MemberServiceImpl();
		int result = service.update(mem);
		System.out.println(result);
		
		
//		request.setAttribute("viewpath", "../member/.jsp");

		response.sendRedirect("/WebProject01/userhistory.do");
	}

}
