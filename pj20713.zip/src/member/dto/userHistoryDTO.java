package member.dto;

public class userHistoryDTO {
	String stock_code;
	int count;
	int price;
	int sum_price;
	
	@Override
	public String toString() {
		return "userHistoryDTO [stock_code=" + stock_code + ", count=" + count
				+ ", price=" + price + ", sum_price=" + sum_price + "]";
	}
	
	public userHistoryDTO(String stock_code, int count, int price, int sum_price) {
		super();
		this.stock_code = stock_code;
		this.count = count;
		this.price = price;
		this.sum_price = sum_price;
	}
	public String getStock_code() {
		return stock_code;
	}
	public void setStock_code(String stock_code) {
		this.stock_code = stock_code;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getSum_price() {
		return sum_price;
	}
	public void setSum_price(int sum_price) {
		this.sum_price = sum_price;
	}
	


	
}