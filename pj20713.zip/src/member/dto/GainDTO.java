package member.dto;

public class GainDTO {

	String crp_nm;
	int pastPrice;
	int nowPrice;
	double gainRate;
	int gain;
	
	@Override
	public String toString() {
		return "GainDTO [crp_nm=" + crp_nm + ", pastPrice=" + pastPrice
				+ ", nowPrice=" + nowPrice + ", gainRate=" + gainRate
				+ ", gain=" + gain + "]";
	}
	public GainDTO(String crp_nm, int pastPrice, int nowPrice, double gainRate,
			int gain) {
		super();
		this.crp_nm = crp_nm;
		this.pastPrice = pastPrice;
		this.nowPrice = nowPrice;
		this.gainRate = gainRate;
		this.gain = gain;
	}
	public String getCrp_nm() {
		return crp_nm;
	}
	public void setCrp_nm(String crp_nm) {
		this.crp_nm = crp_nm;
	}
	public int getPastPrice() {
		return pastPrice;
	}
	public void setPastPrice(int pastPrice) {
		this.pastPrice = pastPrice;
	}
	public int getNowPrice() {
		return nowPrice;
	}
	public void setNowPrice(int nowPrice) {
		this.nowPrice = nowPrice;
	}
	public double getGainRate() {
		return gainRate;
	}
	public void setGainRate(double gainRate) {
		this.gainRate = gainRate;
	}
	public int getGain() {
		return gain;
	}
	public void setGain(int gain) {
		this.gain = gain;
	}
	
	


}
